`timescale 1ns/1ps
module sim;
    localparam IMG_W = 1280;
    localparam IMG_H = 720;
    localparam IMG_SIZE = IMG_W * IMG_H;

    // ---- 时钟 ----
    reg clk_50m, pixclk, clk_100m, clk_74m, ext_rst_n;
    initial clk_50m  = 0; always #10.0  clk_50m  = ~clk_50m;
    initial pixclk   = 0; always #6.73  pixclk   = ~pixclk;    // 74.25M
    initial clk_100m = 0; always #5.0   clk_100m = ~clk_100m;
    initial clk_74m  = 0; always #6.73  clk_74m  = ~clk_74m;

    // ---- 摄像头 DVP 模拟 ----
    reg  [7:0] cam_d;
    reg        fv, lv;
    wire       sda, scl;

    // ---- board_top 接口 ----
    wire cam_ext_clk, cam_rst_n;
    wire lcd_hs, lcd_vs, lcd_de;
    wire [7:0] lcd_r, lcd_g, lcd_b;
    // DDR3 物理引脚（仿真里悬空）
    wire [14:0] ddr_addr; wire [2:0] ddr_ba;
    wire ddr_cas_n, ddr_ck_n, ddr_ck_p, ddr_cke, ddr_cs_n;
    wire [3:0]  ddr_dm;
    wire [31:0] ddr_dq;
    wire [3:0]  ddr_dqs_n, ddr_dqs_p;
    wire ddr_odt, ddr_ras_n, ddr_reset_n, ddr_we_n;

    // 例化被测顶层
    board_top u_board (
        .sys_clk_50m (clk_50m),
        .ext_rst_n   (ext_rst_n),
        .PIXCLK      (pixclk),
        .FV          (fv),
        .LV          (lv),
        .CAM_DATA    (cam_d),
        .CAM_EXT_CLK (cam_ext_clk),
        .CAM_RST_N   (cam_rst_n),
        .SCL         (scl),
        .SDA         (sda),
        .lcd_hs      (lcd_hs),
        .lcd_vs      (lcd_vs),
        .lcd_de      (lcd_de),
        .lcd_r       (lcd_r),
        .lcd_g       (lcd_g),
        .lcd_b       (lcd_b),
        .key_plus    (1'b0),
        .key_minus   (1'b0),
        .ddr_addr    (ddr_addr),
        .ddr_ba      (ddr_ba),
        .ddr_cas_n   (ddr_cas_n),
        .ddr_ck_n    (ddr_ck_n),
        .ddr_ck_p    (ddr_ck_p),
        .ddr_cke     (ddr_cke),
        .ddr_cs_n    (ddr_cs_n),
        .ddr_dm      (ddr_dm),
        .ddr_dq      (ddr_dq),
        .ddr_dqs_n   (ddr_dqs_n),
        .ddr_dqs_p   (ddr_dqs_p),
        .ddr_odt     (ddr_odt),
        .ddr_ras_n   (ddr_ras_n),
        .ddr_reset_n (ddr_reset_n),
        .ddr_we_n    (ddr_we_n)
    );

    // ---- 复位 ----
    initial begin
        ext_rst_n = 0;
        #500;
        ext_rst_n = 1;
    end

    // ---- 摄像头 DVP 720p 模拟（至少 12 帧，覆盖等待期）----
    integer f, r, c;
    initial begin
        cam_d = 0; fv = 0; lv = 0;
        wait(ext_rst_n == 1'b1);
        #10000;

        repeat (15) begin
            fv = 1;
            for (r = 0; r < 720; r = r + 1) begin
                lv = 1;
                for (c = 0; c < 1280; c = c + 1) begin
                    @(posedge pixclk);
                    cam_d = cam_d + 1;
                end
                lv = 0;
                repeat (20) @(posedge pixclk);
            end
            fv = 0;
            repeat (100) @(posedge pixclk);
        end
    end

    // ---- LCD 侧捕获 ----
    integer lcd_x, lcd_y, lcd_de_cnt;
    reg     first_frame_done;
    reg [7:0] lcd_result [0:IMG_SIZE-1];

    always @(posedge clk_74m or negedge ext_rst_n) begin
        if (!ext_rst_n) begin
            lcd_x <= 0; lcd_y <= 0;
            lcd_de_cnt <= 0;
            first_frame_done <= 0;
        end else if (lcd_de && !first_frame_done) begin
            lcd_de_cnt <= lcd_de_cnt + 1;
            if (lcd_y < IMG_H && lcd_x < IMG_W)
                lcd_result[lcd_y*IMG_W + lcd_x] <= lcd_r;

            if (lcd_x == IMG_W - 1) begin
                lcd_x <= 0;
                if (lcd_y == IMG_H - 1) begin
                    lcd_y <= 0;
                    if (lcd_de_cnt >= IMG_SIZE - 1) begin
                        first_frame_done <= 1;
                        $display("[TB] First 720p frame done, DE=%0d", lcd_de_cnt+1);
                    end
                end else begin
                    lcd_y <= lcd_y + 1;
                end
            end else lcd_x <= lcd_x + 1;
        end
    end

    // ---- 仿真结束 & 保存 ----
    integer f_out, k;
    initial begin
        $dumpfile("sim_final.vcd");
        $dumpvars(0, sim);

        wait(first_frame_done == 1);
        repeat (200) @(posedge clk_74m);

        f_out = $fopen("lcd_720p.pgm", "wb");
        $fwrite(f_out, "P5\n%d %d\n255\n", IMG_W, IMG_H);
        for (k = 0; k < IMG_SIZE; k = k + 1)
            $fwrite(f_out, "%c", lcd_result[k]);
        $fclose(f_out);

        $display("[TB] Saved lcd_720p.pgm");
        $finish;
    end

    initial begin
        #5_000_000_000;
        $display("[TB] TIMEOUT");
        $finish;
    end
endmodule