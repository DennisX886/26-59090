`timescale 1ns/1ns
module camera_top
(
    // ============ 板级信号 ============
    input               clk_sys,        // ★ 改名：96MHz（原 clk_27m）
    input               ext_rst_n,

    // ============ AR0135 硬件 DVP 引脚 ============
    input               PIXCLK,
    input               FV,
    input               LV,
    input       [7:0]   CAM_DATA,
    // ★ CAM_EXT_CLK 不再由 camera_top 驱动（外部直接驱动）
    output reg          CAM_RST_N,
    output              SCL,
    // SDA 三端口
    input               SDA_IN,
    output              SDA_OUT,
    output              SDA_OE,

    // ============ 状态调试 ============
    output              cam_init_ok,

    // ============ 对外像素流 ============
    output              frame_vsync,
    output              frame_href,
    output      [7:0]   frame_data,
    output              frame_end_pulse
);

// ==================== 内部 wire ====================
wire sys_rst_n;

// I2C 底层模块信号
wire i2c_sdat_o;
wire i2c_sdat_oe;
wire i2c_sdat_i;
wire [7:0]  i2c_config_index;
wire [39:0] i2c_config_data;
wire        i2c_config_done;
wire [15:0] i2c_rdata;

// 寄存器 LUT 表信号
wire [31:0] lut_data;
wire [7:0]  lut_size;

// DVP 采集输出
wire [7:0]  cmos_fps_rate;
wire [11:0] pixel_cnt;
wire [11:0] line_cnt;

// ==================== 复位同步 ====================
reg [2:0] rst_sync;
always @(posedge clk_sys or negedge ext_rst_n) begin     // ★ 时钟改名
    if(!ext_rst_n)
        rst_sync <= 3'd0;
    else
        rst_sync <= {rst_sync[1:0], 1'b1};
end
assign sys_rst_n = rst_sync[2];

// ==================== 摄像头硬件复位时序 ====================
localparam RST_DELAY_CNT = 19'd200;
reg [18:0] cam_rst_delay_cnt;
always @(posedge clk_sys or negedge sys_rst_n) begin     // ★ 时钟改名
    if(!sys_rst_n) begin
        CAM_RST_N <= 1'b0;
        cam_rst_delay_cnt <= 19'd0;
    end else begin
        if(cam_rst_delay_cnt < RST_DELAY_CNT) begin
            CAM_RST_N <= 1'b0;
            cam_rst_delay_cnt <= cam_rst_delay_cnt + 1'b1;
        end else begin
            CAM_RST_N <= 1'b1;
        end
    end
end

// ==================== I2C 寄存器 ROM 表 ====================
I2C_AR0135_1280720_Config u_ar0135_reg_lut
(
    .LUT_INDEX(i2c_config_index),
    .LUT_DATA (lut_data),
    .LUT_SIZE (lut_size)
);
assign i2c_config_data = {8'h20, lut_data};

// ==================== I2C 时序底层 ====================
i2c_timing_ctrl_reg16_dat16
#(
    .SIMU_EN     (0),
    .I2C_READ_EN (0),
    .CLK_FREQ    (96_000_000),      // ★ 从 27M 改成 96M
    .I2C_FREQ    (400_000)
)
u_i2c_timing(
    .clk            (clk_sys),      // ★ 时钟改名
    .rst_n          (sys_rst_n && CAM_RST_N),
    .i2c_sclk       (SCL),
    .i2c_sdat_o     (i2c_sdat_o),
    .i2c_sdat_oe    (i2c_sdat_oe),
    .i2c_sdat_i     (i2c_sdat_i),
    .i2c_config_size (lut_size),
    .i2c_config_index(i2c_config_index),
    .i2c_config_data (i2c_config_data),
    .i2c_config_done (i2c_config_done),
    .i2c_rdata       (i2c_rdata)
);

// ★ SDA 三端口拼接
assign SDA_OUT    = i2c_sdat_o;
assign SDA_OE     = i2c_sdat_oe;
assign i2c_sdat_i = SDA_IN;

assign cam_init_ok = i2c_config_done;

// ==================== DVP 灰度采集 ====================
CMOS_Capture_RAW_Gray
#(
    .CMOS_FRAME_WAITCNT(4'd10),
    .CMOS_PCLK_FREQ    (74_250_000)
)
u_cmos_capture(
    .clk_cmos       (clk_sys),      // ★ 时钟改名
    .rst_n          (sys_rst_n),
    .cmos_pclk      (PIXCLK),
    .cmos_xclk      (),             // ★ 悬空（XCLK 由 board_top 外部驱动）
    .cmos_vsync     (FV),
    .cmos_href      (LV),
    .cmos_data      (CAM_DATA),
    .cmos_frame_vsync(frame_vsync),
    .cmos_frame_href (frame_href),
    .cmos_frame_data (frame_data),
    .cmos_fps_rate  (cmos_fps_rate),
    .cmos_vsync_end (frame_end_pulse),
    .pixel_cnt      (pixel_cnt),
    .line_cnt       (line_cnt)
);

endmodule