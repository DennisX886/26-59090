`timescale 1ns/1ps

module sim;

    localparam IMG_W = 640;
    localparam IMG_H = 480;
    localparam IMG_SIZE = IMG_W * IMG_H;

    reg clk_100m, clk_25m, rst_n;
    initial clk_100m = 0;
    always #5  clk_100m = ~clk_100m;
    initial clk_25m = 0;
    always #20 clk_25m = ~clk_25m;

    // 图像缓存
    reg [7:0] noisy_img       [0:IMG_SIZE-1];
    reg [7:0] edge_result_img [0:IMG_SIZE-1];
    reg [7:0] lcd_result_img  [0:IMG_SIZE-1];

    integer i, x, y, f_out, noise_seed;
    reg [7:0] threshold;

    // system_top 接口
    reg         start_frame;
    reg         in_valid;
    reg  [7:0]  in_pixel;
    wire        lcd_hs, lcd_vs, lcd_de;
    wire [7:0]  lcd_r, lcd_g, lcd_b;
    wire        ep_valid;
    wire [7:0]  ep_data;
    wire [9:0]  ep_x;
    wire [8:0]  ep_y;

    // 例化系统顶层
    system_top #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_top (
        .clk_100m        (clk_100m),
        .clk_25m         (clk_25m),
        .rst_n           (rst_n),
        .start_frame     (start_frame),
        .in_valid        (in_valid),
        .in_pixel        (in_pixel),
        .threshold       (threshold),
        .lcd_hs          (lcd_hs),
        .lcd_vs          (lcd_vs),
        .lcd_de          (lcd_de),
        .lcd_r           (lcd_r),
        .lcd_g           (lcd_g),
        .lcd_b           (lcd_b),
        .edge_pixel_valid(ep_valid),
        .edge_pixel      (ep_data),
        .edge_x          (ep_x),
        .edge_y          (ep_y)
    );

    // 捕获 edge_detect 输出
    always @(posedge clk_100m)
        if (ep_valid)
            edge_result_img[ep_y*IMG_W + ep_x] <= ep_data;

    // LCD 侧捕获（第一帧）
    integer lcd_x, lcd_y;
    integer lcd_de_cnt, lcd_frame_de_cnt;
    reg     first_frame_done;

    always @(posedge clk_25m or negedge rst_n) begin
        if (!rst_n) begin
            lcd_x <= 0; lcd_y <= 0;
            lcd_de_cnt <= 0; lcd_frame_de_cnt <= 0;
            first_frame_done <= 0;
        end else if (lcd_de && !first_frame_done) begin
            lcd_de_cnt <= lcd_de_cnt + 1;
            lcd_frame_de_cnt <= lcd_frame_de_cnt + 1;

            if (lcd_y < IMG_H && lcd_x < IMG_W)
                lcd_result_img[lcd_y*IMG_W + lcd_x] <= lcd_r;

            if (lcd_x == IMG_W - 1) begin
                lcd_x <= 0;
                if (lcd_y == IMG_H - 1) lcd_y <= 0;
                else lcd_y <= lcd_y + 1;
            end else lcd_x <= lcd_x + 1;

            if (lcd_frame_de_cnt == IMG_SIZE - 1) begin
                first_frame_done <= 1;
                $display("[TB] First LCD frame done, DE=%0d", lcd_frame_de_cnt + 1);
            end
        end
    end

    // 图像生成（与原 TB 一致）
    function [7:0] make_pixel;
        input integer px, py;
        begin
            make_pixel = 8'd20;
            if ((px >= 50)  && (px < 170) && (py >= 50)  && (py < 160)) make_pixel = 8'd52;
            if ((px >= 220) && (px < 340) && (py >= 50)  && (py < 160)) make_pixel = 8'd55;
            if ((px >= 390) && (px < 510) && (py >= 50)  && (py < 160)) make_pixel = 8'd100;
            if ((px >= 130) && (px < 330) && (py >= 250) && (py < 400)) make_pixel = 8'd220;
        end
    endfunction

    task save_edge_pgm;
        integer m;
        begin
            f_out = $fopen("edge_stage.pgm", "wb");
            $fwrite(f_out, "P5\n%d %d\n255\n", IMG_W, IMG_H);
            for (m = 0; m < IMG_SIZE; m = m + 1)
                $fwrite(f_out, "%c", edge_result_img[m]);
            $fclose(f_out);
        end
    endtask

    task save_lcd_pgm;
        integer m;
        begin
            f_out = $fopen("lcd_stage.pgm", "wb");
            $fwrite(f_out, "P5\n%d %d\n255\n", IMG_W, IMG_H);
            for (m = 0; m < IMG_SIZE; m = m + 1)
                $fwrite(f_out, "%c", lcd_result_img[m]);
            $fclose(f_out);
        end
    endtask

    initial begin
        $dumpfile("sim_system.vcd");
        $dumpvars(0, sim);

        clk_100m = 0; clk_25m = 0; rst_n = 0;
        start_frame = 0; in_valid = 0; in_pixel = 0;
        threshold = 8'd128;
        noise_seed = 32'h13572468;

        for (i = 0; i < IMG_SIZE; i = i + 1) begin
            noisy_img[i] = 0; edge_result_img[i] = 0; lcd_result_img[i] = 0;
        end

        #200; rst_n = 1;
        for (y = 0; y < IMG_H; y = y + 1)
            for (x = 0; x < IMG_W; x = x + 1)
                noisy_img[y*IMG_W + x] = make_pixel(x, y);

        #100;

        // 发 start_frame 脉冲
        @(posedge clk_100m); start_frame = 1;
        @(posedge clk_100m); start_frame = 0;

        // 流式发送 307200 个像素
        for (y = 0; y < IMG_H; y = y + 1) begin
            for (x = 0; x < IMG_W; x = x + 1) begin
                @(posedge clk_100m);
                in_valid = 1;
                in_pixel = noisy_img[y*IMG_W + x];
            end
        end
        @(posedge clk_100m); in_valid = 0;

        // 等 LCD 第一帧
        wait (first_frame_done);
        repeat (200) @(posedge clk_25m);

        save_edge_pgm;
        save_lcd_pgm;

        $display("[TB] System simulation done.");
        $display("     edge_stage.pgm  (edge detector output)");
        $display("     lcd_stage.pgm   (LCD output)");

        #200; $finish;
    end

    initial begin
        #500_000_000;
        $display("[TB] TIMEOUT");
        $finish;
    end

endmodule