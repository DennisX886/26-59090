module vga_1280_720_timing(
    input               pix_clk,       // 74.25 MHz
    input               rst_n,
    output reg          hs,
    output reg          vs,
    output reg          de,
    output reg [11:0]   h_cnt,         // 0~1649，需 11 位以上
    output reg [11:0]   v_cnt
);

// 720p@60Hz CVT 标准
parameter H_SYNC  = 40;
parameter H_BACK  = 220;
parameter H_ACT   = 1280;
parameter H_FRONT = 110;
parameter H_TOTAL = H_SYNC + H_BACK + H_ACT + H_FRONT;  // 1650

parameter V_SYNC  = 5;
parameter V_BACK  = 20;
parameter V_ACT   = 720;
parameter V_FRONT = 5;
parameter V_TOTAL = V_SYNC + V_BACK + V_ACT + V_FRONT;  // 750

always @(posedge pix_clk or negedge rst_n) begin
    if (!rst_n) begin
        h_cnt <= 0;
        v_cnt <= 0;
    end else begin
        if (h_cnt < H_TOTAL - 1)
            h_cnt <= h_cnt + 1'b1;
        else begin
            h_cnt <= 0;
            if (v_cnt < V_TOTAL - 1)
                v_cnt <= v_cnt + 1'b1;
            else
                v_cnt <= 0;
        end
    end
end

always @(*) begin
    hs = (h_cnt < H_SYNC) ? 1'b0 : 1'b1;
    vs = (v_cnt < V_SYNC) ? 1'b0 : 1'b1;
    de = ( (h_cnt >= H_SYNC+H_BACK) && (h_cnt < H_SYNC+H_BACK+H_ACT)
        && (v_cnt >= V_SYNC+V_BACK) && (v_cnt < V_SYNC+V_BACK+V_ACT) );
end

endmodule