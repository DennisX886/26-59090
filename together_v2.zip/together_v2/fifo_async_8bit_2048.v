`timescale 1ns/1ps
module fifo_async_8bit_2048(
    input  wire        wr_clk,
    input  wire        rd_clk,
    input  wire        wr_rst_n,
    input  wire        rd_rst_n,
    input  wire        wr_en,
    input  wire        rd_en,
    input  wire [7:0]  din,
    output reg  [7:0]  dout,
    output wire        full,
    output wire        empty
);
    localparam DEPTH = 2048;
    reg [7:0]  mem [0:DEPTH-1];
    reg [11:0] wr_ptr = 0;
    reg [11:0] rd_ptr = 0;
    reg [11:0] rd_ptr_sync1 = 0, rd_ptr_sync2 = 0;
    reg [11:0] wr_ptr_sync1 = 0, wr_ptr_sync2 = 0;

    always @(posedge wr_clk or negedge wr_rst_n)
        if (!wr_rst_n) {rd_ptr_sync2, rd_ptr_sync1} <= 0;
        else begin rd_ptr_sync1 <= rd_ptr; rd_ptr_sync2 <= rd_ptr_sync1; end

    always @(posedge rd_clk or negedge rd_rst_n)
        if (!rd_rst_n) {wr_ptr_sync2, wr_ptr_sync1} <= 0;
        else begin wr_ptr_sync1 <= wr_ptr; wr_ptr_sync2 <= wr_ptr_sync1; end

    assign empty = (rd_ptr == wr_ptr_sync2);
    assign full  = ((wr_ptr - rd_ptr_sync2) >= DEPTH);

    always @(posedge wr_clk or negedge wr_rst_n)
        if (!wr_rst_n) wr_ptr <= 0;
        else if (wr_en && !full) begin mem[wr_ptr[10:0]] <= din; wr_ptr <= wr_ptr + 1; end

    always @(posedge rd_clk or negedge rd_rst_n)
        if (!rd_rst_n) rd_ptr <= 0;
        else if (rd_en && !empty) begin dout <= mem[rd_ptr[10:0]]; rd_ptr <= rd_ptr + 1; end
endmodule