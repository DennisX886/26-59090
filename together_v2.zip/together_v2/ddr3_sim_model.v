// ============================================================
// Simulation 版 ddr3_ctrl.v（同名覆盖 Design 版）
// 用数组模拟 DDR3
// ============================================================
`timescale 1ns/1ps
module ddr3_ctrl (
    input              clk,
    input              rst_n,
    input              wr_en,
    input      [24:0]  wr_addr,
    input      [7:0]   wr_data,
    input              rd_en,
    input      [24:0]  rd_addr,
    output reg [7:0]   rd_data,
    output reg         rd_valid
    // 仿真不需要物理引脚
);

    // 2 个 1280×720 缓冲区
    reg [7:0] mem [0:2*1280*720-1];

    integer k;
    initial for (k = 0; k < 2*1280*720; k = k + 1) mem[k] = 8'd0;

    reg        rd_en_d;
    reg [24:0] rd_addr_d;

    always @(posedge clk) begin
        if (wr_en)
            mem[wr_addr] <= wr_data;

        rd_en_d   <= rd_en;
        rd_addr_d <= rd_addr;

        if (rd_en_d) begin
            rd_data  <= mem[rd_addr_d];
            rd_valid <= 1'b1;
        end else begin
            rd_valid <= 1'b0;
        end
    end

endmodule