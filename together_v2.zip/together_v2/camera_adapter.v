`timescale 1ns/1ps
// 摄像头像素流：PIXCLK 域 → 100MHz 域
// 1280×720 全分辨率保留，不做裁剪
module camera_adapter (
    // PIXCLK 域输入
    input             PIXCLK,
    input             cam_vsync,
    input             cam_href,
    input      [7:0]  cam_data,
    input             cam_frame_end,

    // 100MHz 域输出
    input             clk_100m,
    input             rst_n,
    output reg        out_valid,
    output     [7:0]  out_pixel,
    output reg        out_frame_start
);

    wire        fifo_empty;
    wire        fifo_full;

    // 用异步 FIFO 做跨时钟域
fifo_async_8bit_2048 u_fifo_cdc (
    .wr_clk_i        (PIXCLK),
    .rd_clk_i        (clk_100m),
    .a_rst_i         (~rst_n),
    .wr_en_i         (cam_href),
    .rd_en_i         (!fifo_empty),
    .wdata           (cam_data),
    .rdata           (out_pixel),
    .full_o          (fifo_full),
    .empty_o         (fifo_empty),
    .prog_full_o     (),
    .rst_busy        (),
    .wr_datacount_o  (),
    .rd_datacount_o  (),
    .underflow_o     (),
    .overflow_o      ()
);

    always @(posedge clk_100m or negedge rst_n)
        if (!rst_n) out_valid <= 0;
        else        out_valid <= !fifo_empty;

    // 帧结束脉冲同步到 100MHz 域
    reg fe1, fe2, fe3;
    always @(posedge clk_100m or negedge rst_n)
        if (!rst_n) {fe1, fe2, fe3} <= 0;
        else        {fe3, fe2, fe1} <= {fe2, fe1, cam_frame_end};

    always @(posedge clk_100m or negedge rst_n)
        if (!rst_n) out_frame_start <= 0;
        else        out_frame_start <= fe2 & ~fe3;

endmodule