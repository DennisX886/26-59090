`timescale 1ns/1ps
module system_top #(
    parameter IMG_W = 1280,
    parameter IMG_H = 720
)(
    input              clk_100m,
    input              clk_25m,        // 保留这个端口名，但实际接 74.25M
    input              rst_n,

    // 输入流
    input              start_frame,
    input              in_valid,
    input      [7:0]   in_pixel,
    input      [7:0]   threshold,

    // DDR 接口（新暴露出来）
    output reg         ddr_wr_en,
    output reg [24:0]  ddr_wr_addr,
    output reg [7:0]   ddr_wr_data,
    output reg         ddr_rd_en,
    output reg [24:0]  ddr_rd_addr,
    input      [7:0]   ddr_rd_data,
    input              ddr_rd_valid,

    // LCD 输出
    output             lcd_hs, lcd_vs, lcd_de,
    output      [7:0]  lcd_r, lcd_g, lcd_b
    // ★ fifo_full 不再作为顶层端口，改为内部 wire
);

    localparam IMG_SIZE = IMG_W * IMG_H;    // 921600

    // ★ fifo_full 是内部 wire，由 display_top 驱动
    wire fifo_full;

    // ===== 状态机 =====
    localparam S_IDLE    = 3'd0;
    localparam S_LOAD    = 3'd1;
    localparam S_EDGE    = 3'd2;
    localparam S_DISPLAY = 3'd3;

    reg [2:0]  state;
    reg [19:0] load_idx;
    reg [19:0] edge_rd_idx;
    reg [19:0] disp_rd_idx;
    reg [1:0]  ddr_wait;

    // ===== edge_detect 接口 =====
    reg         frame_wr_done;
    reg         rd_frame_start;
    reg         rd_pixel_valid;
    reg  [7:0]  rd_pixel;
    wire        proc_rd_ready;
    wire        edge_frame_done;
    wire [1:0]  edge_buf_sel;
    wire        ep_valid;
    wire [7:0]  ep_data;
    wire [10:0] ep_x;
    wire [9:0]  ep_y;

    // ===== display_top 接口 =====
    reg         fifo_wr;
    reg  [7:0]  fifo_wdata;

    // ===== edge_detect 例化 =====
    edge_detect #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_edge (
        .clk             (clk_100m),
        .rst_n           (rst_n),
        .frame_wr_done   (frame_wr_done),
        .buf_sel         (2'd0),
        .proc_rd_ready   (proc_rd_ready),
        .rd_frame_start  (rd_frame_start),
        .rd_pixel_valid  (rd_pixel_valid),
        .rd_pixel        (rd_pixel),
        .threshold       (threshold),
        .edge_frame_done (edge_frame_done),
        .edge_buf_sel    (edge_buf_sel),
        .edge_pixel_valid(ep_valid),
        .edge_pixel      (ep_data),
        .edge_x          (ep_x),
        .edge_y          (ep_y)
    );

    // ===== display_top 例化 =====
    display_top u_disp (
        .sys_clk_100m    (clk_100m),
        .pix_clk_74m     (clk_25m),
        .rst_n           (rst_n),
        .edge_frame_done (edge_frame_done),
        .edge_buf_sel    (edge_buf_sel),
        .fifo_wr         (fifo_wr),
        .fifo_wdata      (fifo_wdata),
        .fifo_full       (fifo_full),      // ★ 连内部 wire
        .lcd_hs          (lcd_hs),
        .lcd_vs          (lcd_vs),
        .lcd_de          (lcd_de),
        .lcd_r           (lcd_r),
        .lcd_g           (lcd_g),
        .lcd_b           (lcd_b)
    );

    // ===== 主状态机 =====
    always @(posedge clk_100m or negedge rst_n) begin
        if (!rst_n) begin
            state          <= S_IDLE;
            load_idx       <= 0;
            edge_rd_idx    <= 0;
            disp_rd_idx    <= 0;
            ddr_wait       <= 0;
            frame_wr_done  <= 0;
            rd_frame_start <= 0;
            rd_pixel_valid <= 0;
            rd_pixel       <= 0;
            ddr_wr_en      <= 0;
            ddr_wr_addr    <= 0;
            ddr_wr_data    <= 0;
            ddr_rd_en      <= 0;
            ddr_rd_addr    <= 0;
            fifo_wr        <= 0;
            fifo_wdata     <= 0;
        end else begin
            case (state)
                // ---------- 空闲 ----------
                S_IDLE: begin
                    if (start_frame) begin
                        state    <= S_LOAD;
                        load_idx <= 0;
                    end
                end

                // ---------- 写入 DDR Ping ----------
                S_LOAD: begin
                    if (in_valid) begin
                        ddr_wr_en   <= 1;
                        ddr_wr_addr <= load_idx;
                        ddr_wr_data <= in_pixel;
                        if (load_idx == IMG_SIZE - 1) begin
                            state         <= S_EDGE;
                            frame_wr_done <= 1;
                            load_idx      <= 0;
                        end else begin
                            load_idx <= load_idx + 1;
                        end
                    end else begin
                        ddr_wr_en <= 0;
                    end
                end

                // ---------- 边缘检测：读 Ping 写 Pong ----------
                S_EDGE: begin
                    frame_wr_done <= 0;

                    if (proc_rd_ready == 1'b0 && edge_rd_idx == 0) begin
                        rd_frame_start <= 1;
                        edge_rd_idx    <= edge_rd_idx + 1;
                    end else begin
                        rd_frame_start <= 0;

                        if (edge_rd_idx > 0 && edge_rd_idx <= IMG_SIZE) begin
                            ddr_rd_en      <= 1;
                            ddr_rd_addr    <= edge_rd_idx - 1;
                            rd_pixel_valid <= ddr_rd_valid;
                            rd_pixel       <= ddr_rd_data;
                            edge_rd_idx    <= edge_rd_idx + 1;
                        end else begin
                            ddr_rd_en      <= 0;
                            rd_pixel_valid <= 0;
                        end
                    end

                    if (ep_valid) begin
                        ddr_wr_en   <= 1;
                        ddr_wr_addr <= IMG_SIZE + ep_y * IMG_W + ep_x;
                        ddr_wr_data <= ep_data;
                    end else begin
                        ddr_wr_en <= 0;
                    end

                    if (edge_frame_done) begin
                        state       <= S_DISPLAY;
                        edge_rd_idx <= 0;
                        disp_rd_idx <= 0;
                        ddr_wait    <= 0;
                    end
                end

                // ---------- 显示：从 DDR Pong 读出到 FIFO ----------
                S_DISPLAY: begin
                    if (!fifo_full && disp_rd_idx < IMG_SIZE) begin
                        ddr_rd_en   <= 1;
                        ddr_rd_addr <= IMG_SIZE + disp_rd_idx;
                        disp_rd_idx <= disp_rd_idx + 1;

                        if (ddr_rd_valid) begin
                            fifo_wr    <= 1;
                            fifo_wdata <= ddr_rd_data;
                        end else begin
                            fifo_wr <= 0;
                        end
                    end else begin
                        ddr_rd_en <= 0;
                        fifo_wr   <= 0;
                    end

                    if (start_frame) begin
                        state    <= S_LOAD;
                        load_idx <= 0;
                    end
                end
            endcase
        end
    end

endmodule