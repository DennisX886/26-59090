// ============================================================
// Design 版 ddr3_ctrl.v
// 内部例化 Efinity IP Catalog 生成的 DDR3 控制器
// ============================================================
module ddr3_ctrl (
    input              clk,
    input              rst_n,
    // 用户侧
    input              wr_en,
    input      [24:0]  wr_addr,
    input      [7:0]   wr_data,
    input              rd_en,
    input      [24:0]  rd_addr,
    output     [7:0]   rd_data,
    output             rd_valid,
    // DDR3 物理引脚
    output [14:0] ddr_addr,
    output [2:0]  ddr_ba,
    output        ddr_cas_n,
    output        ddr_ck_n, ddr_ck_p,
    output        ddr_cke, ddr_cs_n,
    output [3:0]  ddr_dm,
    inout  [31:0] ddr_dq,
    inout  [3:0]  ddr_dqs_n, ddr_dqs_p,
    output        ddr_odt, ddr_ras_n, ddr_reset_n, ddr_we_n
);

    // ★ Efinity IP Catalog 生成 DDR3 IP 后，在这里例化
    // IP 名例如 "ddr3_sdram"，端口按 IP 手册连接
    // 下面为示意：
    ddr3_sdram u_ddr3_ip (
        .clk        (clk),
        .rst_n      (rst_n),
        .wr_en      (wr_en),
        .wr_addr    ({7'b0, wr_addr, 2'b0}),   // 按 IP 地址位宽调整
        .wr_data    ({8'b0, wr_data}),
        .rd_en      (rd_en),
        .rd_addr    ({7'b0, rd_addr, 2'b0}),
        .rd_data    (rd_data),
        .rd_valid   (rd_valid),
        .ddr_addr   (ddr_addr),
        .ddr_ba     (ddr_ba),
        .ddr_cas_n  (ddr_cas_n),
        .ddr_ck_n   (ddr_ck_n),
        .ddr_ck_p   (ddr_ck_p),
        .ddr_cke    (ddr_cke),
        .ddr_cs_n   (ddr_cs_n),
        .ddr_dm     (ddr_dm),
        .ddr_dq     (ddr_dq),
        .ddr_dqs_n  (ddr_dqs_n),
        .ddr_dqs_p  (ddr_dqs_p),
        .ddr_odt    (ddr_odt),
        .ddr_ras_n  (ddr_ras_n),
        .ddr_reset_n(ddr_reset_n),
        .ddr_we_n   (ddr_we_n)
    );

endmodule