`timescale 1ns/1ps

module median_filter #(
    parameter IMG_W = 1280,     // ← 改
    parameter IMG_H = 720       // ← 改
)(
    input              clk,
    input              rst_n,
    input              start_frame,
    input              in_valid,
    input      [7:0]   in_pixel,
    output reg         out_valid,
    output reg [7:0]   out_pixel,
    output reg         frame_done
);

    reg [7:0] line1 [0:IMG_W-1];
    reg [7:0] line2 [0:IMG_W-1];

    reg [10:0] x_cnt;      // ← 改
    reg [8:0]  y_cnt;

    reg [7:0] top_d1, top_d2;
    reg [7:0] mid_d1, mid_d2;
    reg [7:0] bot_d1, bot_d2;
    reg [7:0] top_cur, mid_cur;

    wire [7:0] median_window;
    reg  [7:0] median_comb;

    integer i;

    median9_comb u_median (
        .p11(top_d2), .p12(top_d1), .p13(top_cur),
        .p21(mid_d2), .p22(mid_d1), .p23(mid_cur),
        .p31(bot_d2), .p32(bot_d1), .p33(in_pixel),
        .median_pixel(median_window)
    );

    always @* begin
        top_cur = line2[x_cnt];
        mid_cur = line1[x_cnt];
        if ((x_cnt >= 2) && (y_cnt >= 2))
            median_comb = median_window;
        else
            median_comb = in_pixel;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            x_cnt <= 0; y_cnt <= 0;
            top_d1 <= 0; top_d2 <= 0;
            mid_d1 <= 0; mid_d2 <= 0;
            bot_d1 <= 0; bot_d2 <= 0;
            out_valid <= 0; out_pixel <= 0;
            frame_done <= 0;
            for (i = 0; i < IMG_W; i = i + 1) begin
                line1[i] <= 0;
                line2[i] <= 0;
            end
        end else begin
            out_valid  <= 1'b0;
            frame_done <= 1'b0;

            if (start_frame) begin
                x_cnt <= 0; y_cnt <= 0;
                top_d1 <= 0; top_d2 <= 0;
                mid_d1 <= 0; mid_d2 <= 0;
                bot_d1 <= 0; bot_d2 <= 0;
            end else if (in_valid) begin
                out_valid <= 1'b1;
                out_pixel <= median_comb;

                top_d2 <= top_d1; top_d1 <= top_cur;
                mid_d2 <= mid_d1; mid_d1 <= mid_cur;
                bot_d2 <= bot_d1; bot_d1 <= in_pixel;

                line2[x_cnt] <= line1[x_cnt];
                line1[x_cnt] <= in_pixel;

                if (x_cnt == IMG_W-1) begin
                    x_cnt <= 0;
                    if (y_cnt == IMG_H-1) begin
                        y_cnt      <= 0;
                        frame_done <= 1'b1;
                    end else begin
                        y_cnt <= y_cnt + 1'b1;
                    end
                end else begin
                    x_cnt <= x_cnt + 1'b1;
                end
            end
        end
    end
endmodule


module median9_comb(
    input  wire [7:0] p11, p12, p13,
    input  wire [7:0] p21, p22, p23,
    input  wire [7:0] p31, p32, p33,
    output reg  [7:0] median_pixel
);
    reg [7:0] temp [0:8];
    reg [7:0] tmp;
    integer i, j;

    always @* begin
        temp[0]=p11; temp[1]=p12; temp[2]=p13;
        temp[3]=p21; temp[4]=p22; temp[5]=p23;
        temp[6]=p31; temp[7]=p32; temp[8]=p33;

        for (i = 0; i < 9; i = i + 1)
            for (j = 0; j < 8-i; j = j + 1)
                if (temp[j] > temp[j+1]) begin
                    tmp       = temp[j];
                    temp[j]   = temp[j+1];
                    temp[j+1] = tmp;
                end

        median_pixel = temp[4];
    end
endmodule