module display_top(
    input               sys_clk_100m,       // 100MHz 写时钟域
    input               pix_clk_74m,        // ← 从 25M 改成 74.25M
    input               rst_n,

    input               edge_frame_done,
    input        [1:0]  edge_buf_sel,
    input               fifo_wr,
    input        [7:0]  fifo_wdata,
    output              fifo_full,          // ★ 新增（反压信号）

    output              lcd_hs,
    output              lcd_vs,
    output              lcd_de,
    output [7:0]        lcd_r,
    output [7:0]        lcd_g,
    output [7:0]        lcd_b
);

parameter H_ACT = 1280;     // ← 改
parameter V_ACT = 720;      // ← 改

wire fifo_rd;
wire [7:0] fifo_rdata;
wire fifo_empty;

// 异步 FIFO：100M 写，74.25M 读
fifo_async_8bit_2048 u_fifo_async_8bit_2048(
    .wr_clk_i        (sys_clk_100m),
    .rd_clk_i        (pix_clk_74m),
    .a_rst_i         (~rst_n),           // IP 是高电平复位
    .wr_en_i         (fifo_wr),
    .rd_en_i         (fifo_rd),
    .wdata           (fifo_wdata),
    .rdata           (fifo_rdata),
    .full_o          (fifo_full),
    .empty_o         (fifo_empty),
    // 未用的输出端口，接空
    .prog_full_o     (),
    .rst_busy        (),
    .wr_datacount_o  (),
    .rd_datacount_o  (),
    .underflow_o     (),
    .overflow_o      ()
);

wire [11:0] h_cnt;
wire [11:0] v_cnt;
vga_1280_720_timing u_vga_timing(        // ← 换模块
    .pix_clk(pix_clk_74m),               // ← 改
    .rst_n  (rst_n),
    .hs     (lcd_hs),
    .vs     (lcd_vs),
    .de     (lcd_de),
    .h_cnt  (h_cnt),
    .v_cnt  (v_cnt)
);

assign fifo_rd = lcd_de & (~fifo_empty);

assign lcd_r = fifo_rdata;
assign lcd_g = fifo_rdata;
assign lcd_b = fifo_rdata;

endmodule