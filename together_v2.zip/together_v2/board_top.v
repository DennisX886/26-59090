`timescale 1ns/1ps

// ============================================================
// board_top.v —— 板级顶层
// ============================================================
module board_top (
    // ================== 时钟与复位 ==================
    input  wire        clk_24m,           // C5   3.3V
    input  wire        ext_rst_n,         // B2   1.8V

    // ★★★ PLL 硬核输出 ★★★
    input  wire        pll_sys_CLKOUT0,   // 96 MHz
    input  wire        pll_sys_CLKOUT1,   // 74.1818 MHz
    input  wire        pll_sys_CLKOUT2,   // 26.9752 MHz（保留但不用）

    // ================== 摄像头 DVP 接口 ==================
    input  wire        PIXCLK,
    input  wire        FV,
    input  wire        LV,
    input  wire [7:0]  CAM_DATA,
    output wire        CAM_EXT_CLK,       // ★ 由计数器分频产生
    output wire        CAM_RST_N,
    output wire        SCL,
    input  wire        SDA_IN,
    output wire        SDA_OUT,
    output wire        SDA_OE,

    // ================== 调试/握手输出 ==================
    output wire        cam_init_ok,
    output wire        frame_wr_done,
    output wire [1:0]  buf_sel,
    input  wire        proc_rd_ready,

    // ================== LCD/LVDS 输出 ==================
    output wire        lcd_hs,
    output wire        lcd_vs,
    output wire        lcd_de,
    output wire [7:0]  lcd_r,
    output wire [7:0]  lcd_g,
    output wire [7:0]  lcd_b,

    // ================== 按键 ==================
    input  wire        User_IO1,
    input  wire        User_IO0
);

    // ========================================================
    // 1. 时钟网络
    // ========================================================
    wire sys_clk_100m = pll_sys_CLKOUT0;   // 96 MHz
    wire pix_clk_74m  = pll_sys_CLKOUT1;   // 74.1818 MHz
    // pll_sys_CLKOUT2 保留但悬空（不再用于驱动摄像头）

    reg [19:0] rst_cnt    = 20'd0;
    reg        pll_locked = 1'b0;

    always @(posedge sys_clk_100m) begin
        if (rst_cnt < 20'hFFFFF) begin
            rst_cnt    <= rst_cnt + 1'b1;
            pll_locked <= 1'b0;
        end else begin
            pll_locked <= 1'b1;
        end
    end

    wire sys_rst_n = ext_rst_n & pll_locked;

    // ========================================================
    // ★ 摄像头参考时钟：96MHz / 4 = 24MHz 方波（普通寄存器输出）
    //   不使用 pll_sys_CLKOUT2，避免"PLL输出驱动非时钟逻辑"报错
    // ========================================================
    reg [1:0] cam_clk_div    = 2'd0;
    reg       cam_ext_clk_r  = 1'b0;

    always @(posedge sys_clk_100m or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            cam_clk_div   <= 2'd0;
            cam_ext_clk_r <= 1'b0;
        end else begin
            cam_clk_div <= cam_clk_div + 1'b1;
            if (cam_clk_div == 2'd1)
                cam_ext_clk_r <= ~cam_ext_clk_r;   // 24 MHz
        end
    end

    assign CAM_EXT_CLK = cam_ext_clk_r;

    // ========================================================
    // 2. 摄像头模块
    // ========================================================
    wire        cam_vsync, cam_href, cam_frame_end;
    wire        cam_init_ok_w;
    wire [7:0]  cam_data;

    camera_top u_camera (
        .clk_sys        (sys_clk_100m),     // ★ 改用 96MHz
        .ext_rst_n      (sys_rst_n),
        .PIXCLK         (PIXCLK),
        .FV             (FV),
        .LV             (LV),
        .CAM_DATA       (CAM_DATA),
        .CAM_RST_N      (CAM_RST_N),
        .SCL            (SCL),
        .SDA_IN         (SDA_IN),
        .SDA_OUT        (SDA_OUT),
        .SDA_OE         (SDA_OE),
        .cam_init_ok    (cam_init_ok_w),
        .frame_vsync    (cam_vsync),
        .frame_href     (cam_href),
        .frame_data     (cam_data),
        .frame_end_pulse(cam_frame_end)
    );

    assign cam_init_ok = cam_init_ok_w;

    // ========================================================
    // 3. 摄像头适配
    // ========================================================
    wire       adp_valid, adp_frame_start;
    wire [7:0] adp_pixel;

    camera_adapter u_adp (
        .PIXCLK         (PIXCLK),
        .cam_vsync      (cam_vsync),
        .cam_href       (cam_href),
        .cam_data       (cam_data),
        .cam_frame_end  (cam_frame_end),
        .clk_100m       (sys_clk_100m),
        .rst_n          (sys_rst_n),
        .out_valid      (adp_valid),
        .out_pixel      (adp_pixel),
        .out_frame_start(adp_frame_start)
    );

    // ========================================================
    // 4. 按键阈值控制
    // ========================================================
    wire [7:0] threshold;
    key_control #(.CLK_FREQ_HZ(96_000_000)) u_key (
        .clk      (sys_clk_100m),
        .rst_n    (sys_rst_n),
        .key_plus (User_IO1),
        .key_minus(User_IO0),
        .threshold(threshold)
    );

    // ========================================================
    // 5. 系统核心（边缘检测）
    // ========================================================
    wire        ddr_wr_en, ddr_rd_en, ddr_rd_valid;
    wire [24:0] ddr_wr_addr, ddr_rd_addr;
    wire [7:0]  ddr_wr_data, ddr_rd_data;

    system_top #(.IMG_W(1280), .IMG_H(720)) u_sys (
        .clk_100m    (sys_clk_100m),
        .clk_25m     (pix_clk_74m),
        .rst_n       (sys_rst_n),
        .start_frame (adp_frame_start),
        .in_valid    (adp_valid),
        .in_pixel    (adp_pixel),
        .threshold   (threshold),
        .ddr_wr_en   (ddr_wr_en),
        .ddr_wr_addr (ddr_wr_addr),
        .ddr_wr_data (ddr_wr_data),
        .ddr_rd_en   (ddr_rd_en),
        .ddr_rd_addr (ddr_rd_addr),
        .ddr_rd_data (ddr_rd_data),
        .ddr_rd_valid(ddr_rd_valid),
        .lcd_hs      (lcd_hs),
        .lcd_vs      (lcd_vs),
        .lcd_de      (lcd_de),
        .lcd_r       (lcd_r),
        .lcd_g       (lcd_g),
        .lcd_b       (lcd_b)
    );

    // ========================================================
    // 6. 预留握手
    // ========================================================
    assign frame_wr_done = 1'b0;
    assign buf_sel       = 2'b0;

endmodule