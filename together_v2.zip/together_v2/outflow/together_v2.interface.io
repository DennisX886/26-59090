# Efinity IO Placement 
# Interface File: E:/DennisX/Efinity/together_v2/outflow/together_v2.interface.csv
# Version:        2025.1.110.5.9
# Date:           Sep 19 2025

# Copyright (C) 2013 - 2025  All rights reserved.


# pin name     	x	y	z
# --------     	----	----	---
CAM_DATA[0]    	0	3	3
CAM_DATA[1]    	0	4	3
USER_IO0       	0	50	3
USER_IO1       	0	51	1
pll_sys_CLKOUT1	0	159	1
pll_sys_CLKOUT0	0	162	1
pll_sys_CLKOUT2	0	163	1
ext_rst_n      	0	296	3
SCL            	0	312	0
clk_24m        	0	313	3
CAM_DATA[4]    	0	314	3
CAM_DATA[6]    	0	317	3
CAM_DATA[2]    	0	318	3
CAM_RST_N      	0	319	2
FV             	0	321	3
PIXCLK         	86	323	1
cam_init_ok    	219	4	0
buf_sel[1]     	219	5	2
buf_sel[0]     	219	8	2
proc_rd_ready  	219	10	3
frame_wr_done  	219	13	0
SDA_OUT        	219	310	2
SDA_OE         	219	311	0
CAM_DATA[7]    	219	313	3
SDA_IN         	219	314	3
CAM_EXT_CLK    	219	315	0
CAM_DATA[5]    	219	319	3
CAM_DATA[3]    	219	320	3
LV             	219	321	3
