
// Efinity Top-level template
// Version: 2025.1.110.5.9
// Date: 2026-10-14 15:43

// Copyright (C) 2013 - 2025 Efinix Inc. All rights reserved.

// This file may be used as a starting point for Efinity synthesis top-level target.
// The port list here matches what is expected by Efinity constraint files generated
// by the Efinity Interface Designer.

// To use this:
//     #1)  Save this file with a different name to a different directory, where source files are kept.
//              Example: you may wish to save as together_v2.v
//     #2)  Add the newly saved file into Efinity project as design file
//     #3)  Edit the top level entity in Efinity project to:  together_v2
//     #4)  Insert design content.


module together_v2
(
  (* syn_peri_port = 0 *) input [0:7] CAM_DATA,
  (* syn_peri_port = 0 *) input FV,
  (* syn_peri_port = 0 *) input LV,
  (* syn_peri_port = 0 *) input SDA_IN,
  (* syn_peri_port = 0 *) input clk_24m,
  (* syn_peri_port = 0 *) input proc_rd_ready,
  (* syn_peri_port = 0 *) input pll_sys_CLKOUT1,
  (* syn_peri_port = 0 *) input pll_sys_CLKOUT0,
  (* syn_peri_port = 0 *) input pll_sys_CLKOUT2,
  (* syn_peri_port = 0 *) input PIXCLK,
  (* syn_peri_port = 0 *) input USER_IO0,
  (* syn_peri_port = 0 *) input USER_IO1,
  (* syn_peri_port = 0 *) input ext_rst_n,
  (* syn_peri_port = 0 *) output CAM_EXT_CLK,
  (* syn_peri_port = 0 *) output CAM_RST_N,
  (* syn_peri_port = 0 *) output SCL,
  (* syn_peri_port = 0 *) output SDA_OUT,
  (* syn_peri_port = 0 *) output SDA_OE,
  (* syn_peri_port = 0 *) output [0:1] buf_sel,
  (* syn_peri_port = 0 *) output cam_init_ok,
  (* syn_peri_port = 0 *) output frame_wr_done
);


endmodule

