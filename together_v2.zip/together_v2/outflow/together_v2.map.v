
//
// Verific Verilog Description of module board_top
//

module board_top (clk_24m, ext_rst_n, pll_sys_CLKOUT0, pll_sys_CLKOUT1, 
            pll_sys_CLKOUT2, PIXCLK, FV, LV, CAM_DATA, CAM_EXT_CLK, 
            CAM_RST_N, SCL, SDA_IN, SDA_OUT, SDA_OE, cam_init_ok, 
            frame_wr_done, buf_sel, proc_rd_ready, lcd_hs, lcd_vs, 
            lcd_de, lcd_r, lcd_g, lcd_b, User_IO1, User_IO0);
    input clk_24m /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(8)
    input ext_rst_n /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(9)
    input pll_sys_CLKOUT0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(12)
    input pll_sys_CLKOUT1 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(13)
    input pll_sys_CLKOUT2 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(14)
    input PIXCLK /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(17)
    input FV /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(18)
    input LV /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(19)
    input [7:0]CAM_DATA /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(20)
    output CAM_EXT_CLK /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(21)
    output CAM_RST_N /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(22)
    output SCL /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(23)
    input SDA_IN /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(24)
    output SDA_OUT /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(25)
    output SDA_OE /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(26)
    output cam_init_ok /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(29)
    output frame_wr_done /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(30)
    output [1:0]buf_sel /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(31)
    input proc_rd_ready /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(32)
    output lcd_hs /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(35)
    output lcd_vs /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(36)
    output lcd_de /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(37)
    output [7:0]lcd_r /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    output [7:0]lcd_g /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    output [7:0]lcd_b /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    input User_IO1 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(43)
    input User_IO0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_INPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(44)
    
    wire [19:0]n9;
    wire n252;
    wire [18:0]\u_camera/n17 ;
    
    wire \u_camera/add_27/n2 ;
    wire [1:0]cam_clk_div;   // E:\DennisX\Efinity\together_v2\board_top.v(72)
    
    wire pll_locked;
    wire [19:0]rst_cnt;   // E:\DennisX\Efinity\together_v2\board_top.v(54)
    wire [19:0]\u_camera/u_i2c_timing/n9 ;
    
    wire \u_camera/u_i2c_timing/add_319/n2 ;
    wire [18:0]\u_camera/cam_rst_delay_cnt ;   // E:\DennisX\Efinity\together_v2\camera_top.v(64)
    wire [2:0]\u_camera/rst_sync ;   // E:\DennisX\Efinity\together_v2\camera_top.v(53)
    wire [15:0]\u_camera/u_i2c_timing/n79 ;
    
    wire \u_camera/u_i2c_timing/add_322/n2 ;
    wire [15:0]\u_camera/u_i2c_timing/clk_cnt ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(48)
    wire [7:0]\u_camera/u_i2c_timing/n188 ;
    
    wire \u_camera/u_i2c_timing/add_327/n2 ;
    wire [4:0]\u_camera/u_i2c_timing/current_state ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(122)
    
    wire \u_camera/u_i2c_timing/i2c_ctrl_clk , \u_camera/u_i2c_timing/i2c_transfer_en , 
        \u_camera/u_i2c_timing/i2c_capture_en ;
    wire [7:0]\u_camera/i2c_config_index ;   // E:\DennisX\Efinity\together_v2\camera_top.v(38)
    wire [3:0]\u_camera/u_i2c_timing/i2c_stream_cnt ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(158)
    wire [7:0]\u_camera/u_i2c_timing/i2c_wdata ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(300)
    
    wire \u_camera/u_i2c_timing/i2c_ack5 , \u_camera/u_i2c_timing/i2c_ack4 , 
        \u_camera/u_i2c_timing/i2c_ack3 , \u_camera/u_i2c_timing/i2c_ack2 , 
        \u_camera/u_i2c_timing/i2c_ack1 , \u_camera/u_i2c_timing/i2c_ack ;
    wire [19:0]\u_camera/u_i2c_timing/delay_cnt ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(32)
    wire [11:0]\u_sys/u_disp/u_vga_timing/n24 ;
    
    wire \u_sys/u_disp/u_vga_timing/add_32/n16 , \u_sys/u_disp/u_vga_timing/add_32/n14 , 
        \u_sys/u_disp/u_vga_timing/add_32/n12 , \u_sys/u_disp/u_vga_timing/add_32/n10 , 
        \u_sys/u_disp/u_vga_timing/add_32/n8 , \u_sys/u_disp/u_vga_timing/add_32/n6 , 
        \u_sys/u_disp/u_vga_timing/add_32/n4 ;
    wire [11:0]\u_sys/u_disp/u_vga_timing/n9 ;
    
    wire \u_sys/u_disp/u_vga_timing/add_30/n18 , \u_sys/u_disp/u_vga_timing/add_30/n16 , 
        \u_sys/u_disp/u_vga_timing/add_30/n14 , \u_sys/u_disp/u_vga_timing/add_30/n12 , 
        \u_sys/u_disp/u_vga_timing/add_30/n10 , \u_sys/u_disp/u_vga_timing/add_30/n8 , 
        \u_sys/u_disp/u_vga_timing/add_30/n6 , \u_sys/u_disp/u_vga_timing/add_30/n4 , 
        \u_camera/u_i2c_timing/add_327/n6 , \u_camera/u_i2c_timing/add_327/n4 , 
        \u_camera/u_i2c_timing/add_322/n12 , \u_camera/u_i2c_timing/add_322/n10 , 
        \u_camera/u_i2c_timing/add_322/n8 , \u_camera/u_i2c_timing/add_322/n6 , 
        \u_camera/u_i2c_timing/add_322/n4 , \u_sys/u_disp/u_vga_timing/add_30/n2 , 
        \u_sys/u_disp/u_vga_timing/add_32/n2 ;
    wire [11:0]\u_sys/u_disp/v_cnt ;   // E:\DennisX\Efinity\together_v2\display_top.v(48)
    wire [11:0]\u_sys/u_disp/h_cnt ;   // E:\DennisX\Efinity\together_v2\display_top.v(47)
    
    wire \u_camera/u_i2c_timing/add_319/n30 , \u_camera/u_i2c_timing/add_319/n28 , 
        \u_camera/u_i2c_timing/add_319/n26 , \u_camera/u_i2c_timing/add_319/n24 , 
        \u_camera/u_i2c_timing/add_319/n22 , \u_camera/u_i2c_timing/add_319/n20 , 
        \u_camera/u_i2c_timing/add_319/n18 , \u_camera/u_i2c_timing/add_319/n16 , 
        \u_camera/u_i2c_timing/add_319/n14 , \u_camera/u_i2c_timing/add_319/n12 , 
        \u_camera/u_i2c_timing/add_319/n10 , \u_camera/u_i2c_timing/add_319/n8 , 
        \u_camera/u_i2c_timing/add_319/n6 , \u_camera/u_i2c_timing/add_319/n4 , 
        \u_camera/add_27/n12 , \u_camera/add_27/n10 , \u_camera/add_27/n8 , 
        \u_camera/add_27/n6 , \u_camera/add_27/n4 , \add_40/n36 , \add_40/n34 , 
        \add_40/n32 , \add_40/n30 , \add_40/n28 , \add_40/n26 , \add_40/n24 , 
        \add_40/n22 , \add_40/n20 , \add_40/n18 , \add_40/n16 , \add_40/n14 , 
        \add_40/n12 , \add_40/n10 , \add_40/n8 , \add_40/n6 , \add_40/n4 , 
        \add_40/n2 , sys_rst_n, n7, \equal_17/n3 , \u_camera/LessThan_11/n16 ;
    wire [15:0]\u_camera/u_i2c_timing/n121 ;
    
    wire \u_camera/n160 ;
    wire [4:0]\u_camera/u_i2c_timing/next_state ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(122)
    
    wire \u_camera/u_i2c_timing/n138 , \u_camera/u_i2c_timing/n139 , \u_camera/u_i2c_timing/n140 ;
    wire [7:0]\u_camera/u_i2c_timing/n197 ;
    
    wire \u_camera/u_i2c_timing/n832 ;
    wire [3:0]\u_camera/u_i2c_timing/n482 ;
    
    wire ceg_net86;
    wire [7:0]\u_camera/u_i2c_timing/n487 ;
    
    wire ceg_net135, \u_camera/u_i2c_timing/n553 , \u_camera/u_i2c_timing/n556 , 
        \u_camera/u_i2c_timing/n559 , \u_camera/u_i2c_timing/n562 , \u_camera/u_i2c_timing/n565 , 
        \u_camera/u_i2c_timing/n567 , \u_camera/u_i2c_timing/LessThan_6/n34 , 
        \u_camera/u_i2c_timing/n481 , ceg_net129;
    wire [11:0]\u_sys/u_disp/u_vga_timing/n37 ;
    
    wire \u_sys/u_disp/u_vga_timing/LessThan_6/n22 ;
    wire [11:0]\u_sys/u_disp/u_vga_timing/n50 ;
    
    wire n590, n591, n592, n593, n594, n595, n596, n597, n598, 
        n599, n600, n601, n602, n603, n604, n605, n606, n607, 
        n608, n609, n610, n611, n612, n613, n614, n615, n616, 
        n617, n618, n619, n620, n621, n622, n623, n624, n625, 
        n626, n627, n628, n629, n630, n631, n632, n633, n634, 
        n635, n636, n637, n638, n639, n640, n641, n642, n643, 
        n644, n645, n646, n647, n648, n649, n650, n651, n652, 
        n653, n654, n655, n656, n657, n658, n659, n660, n661, 
        n662, n663, n664, n665, n666, n667, n668, n669, n670, 
        n671, n672, n673, n674, n675, n676, n677, n678, n679, 
        n680, n681, n682, n683, n684, n685, n686, n687, n688, 
        n689, n690, n691, n692, n693, n694, n695, n696, n697, 
        n698, n699, n700, n701, n702, n703, n704, n705, n706, 
        n707, n708, n709, n710, n711, n712, n713, n714, n715, 
        n716, n717, n718, n719, n720, n721, n722, n723, n724, 
        n725, n726, n727, n728, n729, n730, n731, n732, n733, 
        n734, n735, n736, n737, n738, n739, n740, n741, n742, 
        n743, n744, n745, n746, n747, n748, n749, n750, n751, 
        n752, n753, n754, n755, n756, n757, n758, n759, n760, 
        n761, n762, n763, n764, n765, n766, n767, n768, n769, 
        n770, n771, n772, n773, n774, n775, n776, n777, n778, 
        n779, n780, n781, n782, n783, n784, n785, n786, n787, 
        n788, n789, n807, n808, n809, n810;
    
    assign frame_wr_done = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(30)
    assign buf_sel[1] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(31)
    assign buf_sel[0] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(31)
    assign lcd_r[7] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[6] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[5] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[4] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[3] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[2] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[1] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_r[0] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(38)
    assign lcd_g[7] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[6] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[5] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[4] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[3] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[2] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_g[1] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(39)
    assign lcd_b[7] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[6] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[5] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[4] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[3] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[2] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[1] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_b[0] = 1'b0 /* verific EFX_ATTRIBUTE_PORT__IS_PRIMARY_OUTPUT=TRUE */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(40)
    assign lcd_g[0] = 1'b0 /* verific EFX_ATTRIBUTE_CELL_NAME=GND */ ;
    EFX_LUT4 LUT__1382 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .O(n590)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1382.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1383 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(n590), 
            .I2(\u_camera/u_i2c_timing/current_state [2]), .I3(\u_camera/u_i2c_timing/current_state [4]), 
            .O(n591)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f00 */ ;
    defparam LUT__1383.LUTMASK = 16'h4f00;
    EFX_FF \cam_clk_div[0]~FF  (.D(cam_clk_div[0]), .CE(1'b1), .CLK(pll_sys_CLKOUT0), 
           .SR(sys_rst_n), .Q(cam_clk_div[0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(83)
    defparam \cam_clk_div[0]~FF .CLK_POLARITY = 1'b1;
    defparam \cam_clk_div[0]~FF .CE_POLARITY = 1'b1;
    defparam \cam_clk_div[0]~FF .SR_POLARITY = 1'b0;
    defparam \cam_clk_div[0]~FF .D_POLARITY = 1'b0;
    defparam \cam_clk_div[0]~FF .SR_SYNC = 1'b0;
    defparam \cam_clk_div[0]~FF .SR_VALUE = 1'b0;
    defparam \cam_clk_div[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \pll_locked~FF  (.D(n7), .CE(1'b1), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(pll_locked)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \pll_locked~FF .CLK_POLARITY = 1'b1;
    defparam \pll_locked~FF .CE_POLARITY = 1'b1;
    defparam \pll_locked~FF .SR_POLARITY = 1'b1;
    defparam \pll_locked~FF .D_POLARITY = 1'b0;
    defparam \pll_locked~FF .SR_SYNC = 1'b1;
    defparam \pll_locked~FF .SR_VALUE = 1'b0;
    defparam \pll_locked~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \CAM_EXT_CLK~FF  (.D(CAM_EXT_CLK), .CE(\equal_17/n3 ), .CLK(pll_sys_CLKOUT0), 
           .SR(sys_rst_n), .Q(CAM_EXT_CLK)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(83)
    defparam \CAM_EXT_CLK~FF .CLK_POLARITY = 1'b1;
    defparam \CAM_EXT_CLK~FF .CE_POLARITY = 1'b0;
    defparam \CAM_EXT_CLK~FF .SR_POLARITY = 1'b0;
    defparam \CAM_EXT_CLK~FF .D_POLARITY = 1'b0;
    defparam \CAM_EXT_CLK~FF .SR_SYNC = 1'b0;
    defparam \CAM_EXT_CLK~FF .SR_VALUE = 1'b0;
    defparam \CAM_EXT_CLK~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[1]~FF  (.D(n9[1]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[1]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[1]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[0]~FF  (.D(rst_cnt[0]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[0]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[0]~FF .D_POLARITY = 1'b0;
    defparam \rst_cnt[0]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \cam_clk_div[1]~FF  (.D(n252), .CE(1'b1), .CLK(pll_sys_CLKOUT0), 
           .SR(sys_rst_n), .Q(cam_clk_div[1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(83)
    defparam \cam_clk_div[1]~FF .CLK_POLARITY = 1'b1;
    defparam \cam_clk_div[1]~FF .CE_POLARITY = 1'b1;
    defparam \cam_clk_div[1]~FF .SR_POLARITY = 1'b0;
    defparam \cam_clk_div[1]~FF .D_POLARITY = 1'b1;
    defparam \cam_clk_div[1]~FF .SR_SYNC = 1'b0;
    defparam \cam_clk_div[1]~FF .SR_VALUE = 1'b0;
    defparam \cam_clk_div[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \CAM_RST_N~FF  (.D(\u_camera/LessThan_11/n16 ), .CE(1'b1), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/rst_sync [2]), .Q(CAM_RST_N)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \CAM_RST_N~FF .CLK_POLARITY = 1'b1;
    defparam \CAM_RST_N~FF .CE_POLARITY = 1'b1;
    defparam \CAM_RST_N~FF .SR_POLARITY = 1'b0;
    defparam \CAM_RST_N~FF .D_POLARITY = 1'b0;
    defparam \CAM_RST_N~FF .SR_SYNC = 1'b0;
    defparam \CAM_RST_N~FF .SR_VALUE = 1'b0;
    defparam \CAM_RST_N~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[0]~FF  (.D(\u_camera/cam_rst_delay_cnt [0]), 
           .CE(\u_camera/LessThan_11/n16 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), 
           .Q(\u_camera/cam_rst_delay_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .D_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/rst_sync[0]~FF  (.D(1'b1), .CE(1'b1), .CLK(pll_sys_CLKOUT0), 
           .SR(sys_rst_n), .Q(\u_camera/rst_sync [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(58)
    defparam \u_camera/rst_sync[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/rst_sync[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/rst_sync[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/rst_sync[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[1]~FF  (.D(\u_camera/n17 [1]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[2]~FF  (.D(\u_camera/n17 [2]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[3]~FF  (.D(\u_camera/n17 [3]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[4]~FF  (.D(\u_camera/n17 [4]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[5]~FF  (.D(\u_camera/n17 [5]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[6]~FF  (.D(\u_camera/n17 [6]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/cam_rst_delay_cnt[7]~FF  (.D(\u_camera/n17 [7]), .CE(\u_camera/LessThan_11/n16 ), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/rst_sync [2]), .Q(\u_camera/cam_rst_delay_cnt [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(76)
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/cam_rst_delay_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[0]~FF  (.D(\u_camera/u_i2c_timing/n121 [0]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/current_state[0]~FF  (.D(\u_camera/u_i2c_timing/next_state [0]), 
           .CE(\u_camera/u_i2c_timing/i2c_transfer_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/current_state [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(128)
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ctrl_clk~FF  (.D(\u_camera/u_i2c_timing/n138 ), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ctrl_clk )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ctrl_clk~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_transfer_en~FF  (.D(\u_camera/u_i2c_timing/n139 ), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_transfer_en )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_transfer_en~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_capture_en~FF  (.D(\u_camera/u_i2c_timing/n140 ), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_capture_en )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_capture_en~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/i2c_config_index[0]~FF  (.D(\u_camera/u_i2c_timing/n197 [0]), 
           .CE(\u_camera/u_i2c_timing/n832 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/i2c_config_index [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(151)
    defparam \u_camera/i2c_config_index[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/i2c_config_index[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/i2c_config_index[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/i2c_config_index[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[7]~FF  (.D(\u_camera/u_i2c_timing/n121 [7]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[6]~FF  (.D(\u_camera/u_i2c_timing/n121 [6]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[5]~FF  (.D(\u_camera/u_i2c_timing/n121 [5]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[4]~FF  (.D(\u_camera/u_i2c_timing/n121 [4]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[3]~FF  (.D(\u_camera/u_i2c_timing/n121 [3]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[2]~FF  (.D(\u_camera/u_i2c_timing/n121 [2]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/clk_cnt[1]~FF  (.D(\u_camera/u_i2c_timing/n121 [1]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/clk_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/clk_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF  (.D(\u_camera/u_i2c_timing/n482 [0]), 
           .CE(ceg_net86), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_stream_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[0]~FF  (.D(\u_camera/u_i2c_timing/n487 [0]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack5~FF  (.D(\u_camera/u_i2c_timing/n553 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack5 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack5~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack4~FF  (.D(\u_camera/u_i2c_timing/n556 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack4~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack3~FF  (.D(\u_camera/u_i2c_timing/n559 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack3 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack3~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack2~FF  (.D(\u_camera/u_i2c_timing/n562 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack2~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack1~FF  (.D(\u_camera/u_i2c_timing/n565 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack1 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack1~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_ack~FF  (.D(\u_camera/u_i2c_timing/n567 ), 
           .CE(\u_camera/u_i2c_timing/i2c_capture_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/i2c_ack )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(492)
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .SR_VALUE = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_ack~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[1]~FF  (.D(\u_camera/u_i2c_timing/n9 [1]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[0]~FF  (.D(\u_camera/u_i2c_timing/delay_cnt [0]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b0, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .D_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \SDA_OUT~FF  (.D(\u_camera/u_i2c_timing/n481 ), .CE(ceg_net129), 
           .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), .Q(SDA_OUT)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b1, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \SDA_OUT~FF .CLK_POLARITY = 1'b1;
    defparam \SDA_OUT~FF .CE_POLARITY = 1'b1;
    defparam \SDA_OUT~FF .SR_POLARITY = 1'b0;
    defparam \SDA_OUT~FF .D_POLARITY = 1'b1;
    defparam \SDA_OUT~FF .SR_SYNC = 1'b0;
    defparam \SDA_OUT~FF .SR_VALUE = 1'b1;
    defparam \SDA_OUT~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/current_state[1]~FF  (.D(\u_camera/u_i2c_timing/next_state [1]), 
           .CE(\u_camera/u_i2c_timing/i2c_transfer_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/current_state [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(128)
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/current_state[2]~FF  (.D(\u_camera/u_i2c_timing/next_state [2]), 
           .CE(\u_camera/u_i2c_timing/i2c_transfer_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/current_state [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(128)
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/current_state[3]~FF  (.D(\u_camera/u_i2c_timing/next_state [3]), 
           .CE(\u_camera/u_i2c_timing/i2c_transfer_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/current_state [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(128)
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/current_state[4]~FF  (.D(\u_camera/u_i2c_timing/next_state [4]), 
           .CE(\u_camera/u_i2c_timing/i2c_transfer_en ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/current_state [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(128)
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/current_state[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/i2c_config_index[1]~FF  (.D(\u_camera/u_i2c_timing/n197 [1]), 
           .CE(\u_camera/u_i2c_timing/n832 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/i2c_config_index [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(151)
    defparam \u_camera/i2c_config_index[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/i2c_config_index[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/i2c_config_index[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/i2c_config_index[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/i2c_config_index[2]~FF  (.D(\u_camera/u_i2c_timing/n197 [2]), 
           .CE(\u_camera/u_i2c_timing/n832 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/i2c_config_index [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(151)
    defparam \u_camera/i2c_config_index[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/i2c_config_index[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/i2c_config_index[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/i2c_config_index[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/i2c_config_index[3]~FF  (.D(\u_camera/u_i2c_timing/n197 [3]), 
           .CE(\u_camera/u_i2c_timing/n832 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/i2c_config_index [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(151)
    defparam \u_camera/i2c_config_index[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/i2c_config_index[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/i2c_config_index[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/i2c_config_index[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/i2c_config_index[4]~FF  (.D(\u_camera/u_i2c_timing/n197 [4]), 
           .CE(\u_camera/u_i2c_timing/n832 ), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/i2c_config_index [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(151)
    defparam \u_camera/i2c_config_index[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/i2c_config_index[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/i2c_config_index[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/i2c_config_index[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/i2c_config_index[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF  (.D(\u_camera/u_i2c_timing/n482 [1]), 
           .CE(ceg_net86), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_stream_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF  (.D(\u_camera/u_i2c_timing/n482 [2]), 
           .CE(ceg_net86), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_stream_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF  (.D(\u_camera/u_i2c_timing/n482 [3]), 
           .CE(ceg_net86), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_stream_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_stream_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[1]~FF  (.D(\u_camera/u_i2c_timing/n487 [1]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[2]~FF  (.D(\u_camera/u_i2c_timing/n487 [2]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[3]~FF  (.D(\u_camera/u_i2c_timing/n487 [3]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[4]~FF  (.D(\u_camera/u_i2c_timing/n487 [4]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[5]~FF  (.D(\u_camera/u_i2c_timing/n487 [5]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[6]~FF  (.D(\u_camera/u_i2c_timing/n487 [6]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/i2c_wdata[7]~FF  (.D(\u_camera/u_i2c_timing/n487 [7]), 
           .CE(ceg_net135), .CLK(pll_sys_CLKOUT0), .SR(\u_camera/n160 ), 
           .Q(\u_camera/u_i2c_timing/i2c_wdata [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(446)
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/i2c_wdata[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[2]~FF  (.D(\u_camera/u_i2c_timing/n9 [2]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[3]~FF  (.D(\u_camera/u_i2c_timing/n9 [3]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[4]~FF  (.D(\u_camera/u_i2c_timing/n9 [4]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[5]~FF  (.D(\u_camera/u_i2c_timing/n9 [5]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[6]~FF  (.D(\u_camera/u_i2c_timing/n9 [6]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[7]~FF  (.D(\u_camera/u_i2c_timing/n9 [7]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[8]~FF  (.D(\u_camera/u_i2c_timing/n9 [8]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[8]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[9]~FF  (.D(\u_camera/u_i2c_timing/n9 [9]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[9]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[10]~FF  (.D(\u_camera/u_i2c_timing/n9 [10]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [10])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[10]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[11]~FF  (.D(\u_camera/u_i2c_timing/n9 [11]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [11])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[11]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[12]~FF  (.D(\u_camera/u_i2c_timing/n9 [12]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [12])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[12]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[13]~FF  (.D(\u_camera/u_i2c_timing/n9 [13]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [13])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[13]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[14]~FF  (.D(\u_camera/u_i2c_timing/n9 [14]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [14])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[14]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[15]~FF  (.D(\u_camera/u_i2c_timing/n9 [15]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [15])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[15]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/u_i2c_timing/delay_cnt[16]~FF  (.D(\u_camera/u_i2c_timing/n9 [16]), 
           .CE(\u_camera/u_i2c_timing/LessThan_6/n34 ), .CLK(pll_sys_CLKOUT0), 
           .SR(\u_camera/n160 ), .Q(\u_camera/u_i2c_timing/delay_cnt [16])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(41)
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/u_i2c_timing/delay_cnt[16]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/rst_sync[1]~FF  (.D(\u_camera/rst_sync [0]), .CE(1'b1), 
           .CLK(pll_sys_CLKOUT0), .SR(sys_rst_n), .Q(\u_camera/rst_sync [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(58)
    defparam \u_camera/rst_sync[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/rst_sync[1]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[1]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/rst_sync[1]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/rst_sync[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_camera/rst_sync[2]~FF  (.D(\u_camera/rst_sync [1]), .CE(1'b1), 
           .CLK(pll_sys_CLKOUT0), .SR(sys_rst_n), .Q(\u_camera/rst_sync [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(58)
    defparam \u_camera/rst_sync[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_camera/rst_sync[2]~FF .D_POLARITY = 1'b1;
    defparam \u_camera/rst_sync[2]~FF .SR_SYNC = 1'b0;
    defparam \u_camera/rst_sync[2]~FF .SR_VALUE = 1'b0;
    defparam \u_camera/rst_sync[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[0]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [0]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[0]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[0]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[0]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [0]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[0]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[0]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[0]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[0]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[0]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[0]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[0]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[1]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [1]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[1]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[2]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [2]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[2]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[3]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [3]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[3]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[4]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [4]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[4]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[4]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[5]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [5]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[5]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[5]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[6]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [6]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[6]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[6]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[7]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [7]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[7]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[7]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[8]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [8]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[8]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[8]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[8]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[8]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[8]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[8]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[8]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/v_cnt[9]~FF  (.D(\u_sys/u_disp/u_vga_timing/n37 [9]), 
           .CE(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), .CLK(pll_sys_CLKOUT1), 
           .SR(sys_rst_n), .Q(\u_sys/u_disp/v_cnt [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b0, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/v_cnt[9]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[9]~FF .CE_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[9]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/v_cnt[9]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/v_cnt[9]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/v_cnt[9]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/v_cnt[9]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[1]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [1]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[1]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[1]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[1]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[1]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[1]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[1]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[1]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[2]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [2]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[2]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[2]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[3]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [3]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[3]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[3]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[4]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [4]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[4]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[4]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[4]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[5]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [5]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[5]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[5]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[5]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[6]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [6]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[6]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[6]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[6]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[7]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [7]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[7]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[7]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[7]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[8]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [8]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[8]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[8]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[8]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[8]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[8]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[8]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[8]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[9]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [9]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[9]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[9]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[9]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[9]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[9]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[9]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[9]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \u_sys/u_disp/h_cnt[10]~FF  (.D(\u_sys/u_disp/u_vga_timing/n50 [10]), 
           .CE(1'b1), .CLK(pll_sys_CLKOUT1), .SR(sys_rst_n), .Q(\u_sys/u_disp/h_cnt [10])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b0, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b0 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(38)
    defparam \u_sys/u_disp/h_cnt[10]~FF .CLK_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[10]~FF .CE_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[10]~FF .SR_POLARITY = 1'b0;
    defparam \u_sys/u_disp/h_cnt[10]~FF .D_POLARITY = 1'b1;
    defparam \u_sys/u_disp/h_cnt[10]~FF .SR_SYNC = 1'b0;
    defparam \u_sys/u_disp/h_cnt[10]~FF .SR_VALUE = 1'b0;
    defparam \u_sys/u_disp/h_cnt[10]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[2]~FF  (.D(n9[2]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[2]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[2]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[2]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[2]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[2]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[2]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[2]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[3]~FF  (.D(n9[3]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[3]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[3]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[3]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[3]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[3]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[3]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[3]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[4]~FF  (.D(n9[4]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[4]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[4]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[4]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[4]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[4]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[4]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[4]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[5]~FF  (.D(n9[5]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[5]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[5]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[5]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[5]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[5]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[5]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[5]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[6]~FF  (.D(n9[6]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[6]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[6]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[6]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[6]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[6]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[6]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[6]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[7]~FF  (.D(n9[7]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[7]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[7]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[7]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[7]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[7]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[7]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[7]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[8]~FF  (.D(n9[8]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[8]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[8]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[8]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[8]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[8]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[8]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[8]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[9]~FF  (.D(n9[9]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[9]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[9]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[9]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[9]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[9]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[9]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[9]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[10]~FF  (.D(n9[10]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[10])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[10]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[10]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[10]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[10]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[10]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[10]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[10]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[11]~FF  (.D(n9[11]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[11])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[11]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[11]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[11]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[11]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[11]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[11]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[11]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[12]~FF  (.D(n9[12]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[12])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[12]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[12]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[12]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[12]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[12]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[12]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[12]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[13]~FF  (.D(n9[13]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[13])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[13]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[13]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[13]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[13]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[13]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[13]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[13]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[14]~FF  (.D(n9[14]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[14])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[14]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[14]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[14]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[14]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[14]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[14]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[14]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[15]~FF  (.D(n9[15]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[15])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[15]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[15]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[15]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[15]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[15]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[15]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[15]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[16]~FF  (.D(n9[16]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[16])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[16]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[16]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[16]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[16]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[16]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[16]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[16]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[17]~FF  (.D(n9[17]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[17])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[17]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[17]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[17]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[17]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[17]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[17]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[17]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[18]~FF  (.D(n9[18]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[18])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[18]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[18]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[18]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[18]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[18]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[18]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[18]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_FF \rst_cnt[19]~FF  (.D(n9[19]), .CE(n7), .CLK(pll_sys_CLKOUT0), 
           .SR(1'b0), .Q(rst_cnt[19])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_FF, CLK_POLARITY=1'b1, D_POLARITY=1'b1, CE_POLARITY=1'b1, SR_SYNC=1'b1, SR_SYNC_PRIORITY=1'b1, SR_VALUE=1'b0, SR_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(64)
    defparam \rst_cnt[19]~FF .CLK_POLARITY = 1'b1;
    defparam \rst_cnt[19]~FF .CE_POLARITY = 1'b1;
    defparam \rst_cnt[19]~FF .SR_POLARITY = 1'b1;
    defparam \rst_cnt[19]~FF .D_POLARITY = 1'b1;
    defparam \rst_cnt[19]~FF .SR_SYNC = 1'b1;
    defparam \rst_cnt[19]~FF .SR_VALUE = 1'b0;
    defparam \rst_cnt[19]~FF .SR_SYNC_PRIORITY = 1'b1;
    EFX_ADD \u_camera/add_27/i1  (.I0(\u_camera/cam_rst_delay_cnt [1]), .I1(\u_camera/cam_rst_delay_cnt [0]), 
            .CI(1'b0), .O(\u_camera/n17 [1]), .CO(\u_camera/add_27/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i1 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i1  (.I0(\u_camera/u_i2c_timing/delay_cnt [1]), 
            .I1(\u_camera/u_i2c_timing/delay_cnt [0]), .CI(1'b0), .O(\u_camera/u_i2c_timing/n9 [1]), 
            .CO(\u_camera/u_i2c_timing/add_319/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i1 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i1  (.I0(\u_camera/u_i2c_timing/clk_cnt [1]), 
            .I1(\u_camera/u_i2c_timing/clk_cnt [0]), .CI(1'b0), .O(\u_camera/u_i2c_timing/n79 [1]), 
            .CO(\u_camera/u_i2c_timing/add_322/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i1 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_327/i1  (.I0(\u_camera/i2c_config_index [1]), 
            .I1(\u_camera/i2c_config_index [0]), .CI(1'b0), .O(\u_camera/u_i2c_timing/n188 [1]), 
            .CO(\u_camera/u_i2c_timing/add_327/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(143)
    defparam \u_camera/u_i2c_timing/add_327/i1 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_327/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i9  (.I0(\u_sys/u_disp/v_cnt [9]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n16 ), .O(\u_sys/u_disp/u_vga_timing/n24 [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i9 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i9 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i8  (.I0(\u_sys/u_disp/v_cnt [8]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n14 ), .O(\u_sys/u_disp/u_vga_timing/n24 [8]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n16 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i8 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i8 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i7  (.I0(\u_sys/u_disp/v_cnt [7]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n12 ), .O(\u_sys/u_disp/u_vga_timing/n24 [7]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n14 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i7 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i6  (.I0(\u_sys/u_disp/v_cnt [6]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n10 ), .O(\u_sys/u_disp/u_vga_timing/n24 [6]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i6 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i5  (.I0(\u_sys/u_disp/v_cnt [5]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n8 ), .O(\u_sys/u_disp/u_vga_timing/n24 [5]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i5 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i4  (.I0(\u_sys/u_disp/v_cnt [4]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n6 ), .O(\u_sys/u_disp/u_vga_timing/n24 [4]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i4 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i3  (.I0(\u_sys/u_disp/v_cnt [3]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n4 ), .O(\u_sys/u_disp/u_vga_timing/n24 [3]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i3 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i2  (.I0(\u_sys/u_disp/v_cnt [2]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_32/n2 ), .O(\u_sys/u_disp/u_vga_timing/n24 [2]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i2 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i10  (.I0(\u_sys/u_disp/h_cnt [10]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n18 ), .O(\u_sys/u_disp/u_vga_timing/n9 [10])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i10 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i10 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i9  (.I0(\u_sys/u_disp/h_cnt [9]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n16 ), .O(\u_sys/u_disp/u_vga_timing/n9 [9]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n18 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i9 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i9 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i8  (.I0(\u_sys/u_disp/h_cnt [8]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n14 ), .O(\u_sys/u_disp/u_vga_timing/n9 [8]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n16 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i8 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i8 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i7  (.I0(\u_sys/u_disp/h_cnt [7]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n12 ), .O(\u_sys/u_disp/u_vga_timing/n9 [7]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n14 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i7 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i6  (.I0(\u_sys/u_disp/h_cnt [6]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n10 ), .O(\u_sys/u_disp/u_vga_timing/n9 [6]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i6 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i5  (.I0(\u_sys/u_disp/h_cnt [5]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n8 ), .O(\u_sys/u_disp/u_vga_timing/n9 [5]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i5 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i4  (.I0(\u_sys/u_disp/h_cnt [4]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n6 ), .O(\u_sys/u_disp/u_vga_timing/n9 [4]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i4 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i3  (.I0(\u_sys/u_disp/h_cnt [3]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n4 ), .O(\u_sys/u_disp/u_vga_timing/n9 [3]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i3 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i2  (.I0(\u_sys/u_disp/h_cnt [2]), 
            .I1(1'b0), .CI(\u_sys/u_disp/u_vga_timing/add_30/n2 ), .O(\u_sys/u_disp/u_vga_timing/n9 [2]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i2 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_327/i4  (.I0(\u_camera/i2c_config_index [4]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_327/n6 ), .O(\u_camera/u_i2c_timing/n188 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(143)
    defparam \u_camera/u_i2c_timing/add_327/i4 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_327/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_327/i3  (.I0(\u_camera/i2c_config_index [3]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_327/n4 ), .O(\u_camera/u_i2c_timing/n188 [3]), 
            .CO(\u_camera/u_i2c_timing/add_327/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(143)
    defparam \u_camera/u_i2c_timing/add_327/i3 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_327/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_327/i2  (.I0(\u_camera/i2c_config_index [2]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_327/n2 ), .O(\u_camera/u_i2c_timing/n188 [2]), 
            .CO(\u_camera/u_i2c_timing/add_327/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(143)
    defparam \u_camera/u_i2c_timing/add_327/i2 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_327/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i7  (.I0(\u_camera/u_i2c_timing/clk_cnt [7]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n12 ), .O(\u_camera/u_i2c_timing/n79 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i7 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i6  (.I0(\u_camera/u_i2c_timing/clk_cnt [6]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n10 ), .O(\u_camera/u_i2c_timing/n79 [6]), 
            .CO(\u_camera/u_i2c_timing/add_322/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i6 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i5  (.I0(\u_camera/u_i2c_timing/clk_cnt [5]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n8 ), .O(\u_camera/u_i2c_timing/n79 [5]), 
            .CO(\u_camera/u_i2c_timing/add_322/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i5 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i4  (.I0(\u_camera/u_i2c_timing/clk_cnt [4]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n6 ), .O(\u_camera/u_i2c_timing/n79 [4]), 
            .CO(\u_camera/u_i2c_timing/add_322/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i4 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i3  (.I0(\u_camera/u_i2c_timing/clk_cnt [3]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n4 ), .O(\u_camera/u_i2c_timing/n79 [3]), 
            .CO(\u_camera/u_i2c_timing/add_322/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i3 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_322/i2  (.I0(\u_camera/u_i2c_timing/clk_cnt [2]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_322/n2 ), .O(\u_camera/u_i2c_timing/n79 [2]), 
            .CO(\u_camera/u_i2c_timing/add_322/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(65)
    defparam \u_camera/u_i2c_timing/add_322/i2 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_322/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_30/i1  (.I0(\u_sys/u_disp/h_cnt [1]), 
            .I1(\u_sys/u_disp/h_cnt [0]), .CI(1'b0), .O(\u_sys/u_disp/u_vga_timing/n9 [1]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_30/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(30)
    defparam \u_sys/u_disp/u_vga_timing/add_30/i1 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_30/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_sys/u_disp/u_vga_timing/add_32/i1  (.I0(\u_sys/u_disp/v_cnt [1]), 
            .I1(\u_sys/u_disp/v_cnt [0]), .CI(1'b0), .O(\u_sys/u_disp/u_vga_timing/n24 [1]), 
            .CO(\u_sys/u_disp/u_vga_timing/add_32/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(34)
    defparam \u_sys/u_disp/u_vga_timing/add_32/i1 .I0_POLARITY = 1'b1;
    defparam \u_sys/u_disp/u_vga_timing/add_32/i1 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i16  (.I0(\u_camera/u_i2c_timing/delay_cnt [16]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n30 ), .O(\u_camera/u_i2c_timing/n9 [16])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i16 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i16 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i15  (.I0(\u_camera/u_i2c_timing/delay_cnt [15]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n28 ), .O(\u_camera/u_i2c_timing/n9 [15]), 
            .CO(\u_camera/u_i2c_timing/add_319/n30 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i15 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i15 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i14  (.I0(\u_camera/u_i2c_timing/delay_cnt [14]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n26 ), .O(\u_camera/u_i2c_timing/n9 [14]), 
            .CO(\u_camera/u_i2c_timing/add_319/n28 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i14 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i14 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i13  (.I0(\u_camera/u_i2c_timing/delay_cnt [13]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n24 ), .O(\u_camera/u_i2c_timing/n9 [13]), 
            .CO(\u_camera/u_i2c_timing/add_319/n26 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i13 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i13 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i12  (.I0(\u_camera/u_i2c_timing/delay_cnt [12]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n22 ), .O(\u_camera/u_i2c_timing/n9 [12]), 
            .CO(\u_camera/u_i2c_timing/add_319/n24 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i12 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i12 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i11  (.I0(\u_camera/u_i2c_timing/delay_cnt [11]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n20 ), .O(\u_camera/u_i2c_timing/n9 [11]), 
            .CO(\u_camera/u_i2c_timing/add_319/n22 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i11 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i11 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i10  (.I0(\u_camera/u_i2c_timing/delay_cnt [10]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n18 ), .O(\u_camera/u_i2c_timing/n9 [10]), 
            .CO(\u_camera/u_i2c_timing/add_319/n20 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i10 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i10 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i9  (.I0(\u_camera/u_i2c_timing/delay_cnt [9]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n16 ), .O(\u_camera/u_i2c_timing/n9 [9]), 
            .CO(\u_camera/u_i2c_timing/add_319/n18 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i9 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i9 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i8  (.I0(\u_camera/u_i2c_timing/delay_cnt [8]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n14 ), .O(\u_camera/u_i2c_timing/n9 [8]), 
            .CO(\u_camera/u_i2c_timing/add_319/n16 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i8 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i8 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i7  (.I0(\u_camera/u_i2c_timing/delay_cnt [7]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n12 ), .O(\u_camera/u_i2c_timing/n9 [7]), 
            .CO(\u_camera/u_i2c_timing/add_319/n14 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i7 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i6  (.I0(\u_camera/u_i2c_timing/delay_cnt [6]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n10 ), .O(\u_camera/u_i2c_timing/n9 [6]), 
            .CO(\u_camera/u_i2c_timing/add_319/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i6 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i5  (.I0(\u_camera/u_i2c_timing/delay_cnt [5]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n8 ), .O(\u_camera/u_i2c_timing/n9 [5]), 
            .CO(\u_camera/u_i2c_timing/add_319/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i5 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i4  (.I0(\u_camera/u_i2c_timing/delay_cnt [4]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n6 ), .O(\u_camera/u_i2c_timing/n9 [4]), 
            .CO(\u_camera/u_i2c_timing/add_319/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i4 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i3  (.I0(\u_camera/u_i2c_timing/delay_cnt [3]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n4 ), .O(\u_camera/u_i2c_timing/n9 [3]), 
            .CO(\u_camera/u_i2c_timing/add_319/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i3 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/u_i2c_timing/add_319/i2  (.I0(\u_camera/u_i2c_timing/delay_cnt [2]), 
            .I1(1'b0), .CI(\u_camera/u_i2c_timing/add_319/n2 ), .O(\u_camera/u_i2c_timing/n9 [2]), 
            .CO(\u_camera/u_i2c_timing/add_319/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(39)
    defparam \u_camera/u_i2c_timing/add_319/i2 .I0_POLARITY = 1'b1;
    defparam \u_camera/u_i2c_timing/add_319/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i7  (.I0(\u_camera/cam_rst_delay_cnt [7]), .I1(1'b0), 
            .CI(\u_camera/add_27/n12 ), .O(\u_camera/n17 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i7 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i6  (.I0(\u_camera/cam_rst_delay_cnt [6]), .I1(1'b0), 
            .CI(\u_camera/add_27/n10 ), .O(\u_camera/n17 [6]), .CO(\u_camera/add_27/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i6 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i5  (.I0(\u_camera/cam_rst_delay_cnt [5]), .I1(1'b0), 
            .CI(\u_camera/add_27/n8 ), .O(\u_camera/n17 [5]), .CO(\u_camera/add_27/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i5 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i4  (.I0(\u_camera/cam_rst_delay_cnt [4]), .I1(1'b0), 
            .CI(\u_camera/add_27/n6 ), .O(\u_camera/n17 [4]), .CO(\u_camera/add_27/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i4 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i3  (.I0(\u_camera/cam_rst_delay_cnt [3]), .I1(1'b0), 
            .CI(\u_camera/add_27/n4 ), .O(\u_camera/n17 [3]), .CO(\u_camera/add_27/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i3 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \u_camera/add_27/i2  (.I0(\u_camera/cam_rst_delay_cnt [2]), .I1(1'b0), 
            .CI(\u_camera/add_27/n2 ), .O(\u_camera/n17 [2]), .CO(\u_camera/add_27/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(72)
    defparam \u_camera/add_27/i2 .I0_POLARITY = 1'b1;
    defparam \u_camera/add_27/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i19  (.I0(rst_cnt[19]), .I1(1'b0), .CI(\add_40/n36 ), 
            .O(n9[19])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i19 .I0_POLARITY = 1'b1;
    defparam \add_40/i19 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i18  (.I0(rst_cnt[18]), .I1(1'b0), .CI(\add_40/n34 ), 
            .O(n9[18]), .CO(\add_40/n36 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i18 .I0_POLARITY = 1'b1;
    defparam \add_40/i18 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i17  (.I0(rst_cnt[17]), .I1(1'b0), .CI(\add_40/n32 ), 
            .O(n9[17]), .CO(\add_40/n34 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i17 .I0_POLARITY = 1'b1;
    defparam \add_40/i17 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i16  (.I0(rst_cnt[16]), .I1(1'b0), .CI(\add_40/n30 ), 
            .O(n9[16]), .CO(\add_40/n32 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i16 .I0_POLARITY = 1'b1;
    defparam \add_40/i16 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i15  (.I0(rst_cnt[15]), .I1(1'b0), .CI(\add_40/n28 ), 
            .O(n9[15]), .CO(\add_40/n30 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i15 .I0_POLARITY = 1'b1;
    defparam \add_40/i15 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i14  (.I0(rst_cnt[14]), .I1(1'b0), .CI(\add_40/n26 ), 
            .O(n9[14]), .CO(\add_40/n28 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i14 .I0_POLARITY = 1'b1;
    defparam \add_40/i14 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i13  (.I0(rst_cnt[13]), .I1(1'b0), .CI(\add_40/n24 ), 
            .O(n9[13]), .CO(\add_40/n26 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i13 .I0_POLARITY = 1'b1;
    defparam \add_40/i13 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i12  (.I0(rst_cnt[12]), .I1(1'b0), .CI(\add_40/n22 ), 
            .O(n9[12]), .CO(\add_40/n24 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i12 .I0_POLARITY = 1'b1;
    defparam \add_40/i12 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i11  (.I0(rst_cnt[11]), .I1(1'b0), .CI(\add_40/n20 ), 
            .O(n9[11]), .CO(\add_40/n22 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i11 .I0_POLARITY = 1'b1;
    defparam \add_40/i11 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i10  (.I0(rst_cnt[10]), .I1(1'b0), .CI(\add_40/n18 ), 
            .O(n9[10]), .CO(\add_40/n20 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i10 .I0_POLARITY = 1'b1;
    defparam \add_40/i10 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i9  (.I0(rst_cnt[9]), .I1(1'b0), .CI(\add_40/n16 ), 
            .O(n9[9]), .CO(\add_40/n18 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i9 .I0_POLARITY = 1'b1;
    defparam \add_40/i9 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i8  (.I0(rst_cnt[8]), .I1(1'b0), .CI(\add_40/n14 ), 
            .O(n9[8]), .CO(\add_40/n16 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i8 .I0_POLARITY = 1'b1;
    defparam \add_40/i8 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i7  (.I0(rst_cnt[7]), .I1(1'b0), .CI(\add_40/n12 ), 
            .O(n9[7]), .CO(\add_40/n14 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i7 .I0_POLARITY = 1'b1;
    defparam \add_40/i7 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i6  (.I0(rst_cnt[6]), .I1(1'b0), .CI(\add_40/n10 ), 
            .O(n9[6]), .CO(\add_40/n12 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i6 .I0_POLARITY = 1'b1;
    defparam \add_40/i6 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i5  (.I0(rst_cnt[5]), .I1(1'b0), .CI(\add_40/n8 ), 
            .O(n9[5]), .CO(\add_40/n10 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i5 .I0_POLARITY = 1'b1;
    defparam \add_40/i5 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i4  (.I0(rst_cnt[4]), .I1(1'b0), .CI(\add_40/n6 ), 
            .O(n9[4]), .CO(\add_40/n8 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i4 .I0_POLARITY = 1'b1;
    defparam \add_40/i4 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i3  (.I0(rst_cnt[3]), .I1(1'b0), .CI(\add_40/n4 ), 
            .O(n9[3]), .CO(\add_40/n6 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i3 .I0_POLARITY = 1'b1;
    defparam \add_40/i3 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i2  (.I0(rst_cnt[2]), .I1(1'b0), .CI(\add_40/n2 ), 
            .O(n9[2]), .CO(\add_40/n4 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i2 .I0_POLARITY = 1'b1;
    defparam \add_40/i2 .I1_POLARITY = 1'b1;
    EFX_ADD \add_40/i1  (.I0(rst_cnt[1]), .I1(rst_cnt[0]), .CI(1'b0), 
            .O(n9[1]), .CO(\add_40/n2 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_ADD, I0_POLARITY=1'b1, I1_POLARITY=1'b1 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(59)
    defparam \add_40/i1 .I0_POLARITY = 1'b1;
    defparam \add_40/i1 .I1_POLARITY = 1'b1;
    EFX_LUT4 LUT__1384 (.I0(\u_camera/u_i2c_timing/current_state [3]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(\u_camera/u_i2c_timing/current_state [1]), .I3(\u_camera/u_i2c_timing/current_state [4]), 
            .O(n592)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h00f4 */ ;
    defparam LUT__1384.LUTMASK = 16'h00f4;
    EFX_LUT4 LUT__1385 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(\u_camera/u_i2c_timing/current_state [2]), .I3(\u_camera/u_i2c_timing/current_state [3]), 
            .O(n593)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf077 */ ;
    defparam LUT__1385.LUTMASK = 16'hf077;
    EFX_LUT4 LUT__1386 (.I0(n592), .I1(n591), .I2(n593), .I3(\u_camera/u_i2c_timing/i2c_ctrl_clk ), 
            .O(SCL)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hff10 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(501)
    defparam LUT__1386.LUTMASK = 16'hff10;
    EFX_LUT4 LUT__1387 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(\u_camera/u_i2c_timing/current_state [3]), .I3(\u_camera/u_i2c_timing/current_state [4]), 
            .O(n594)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h233f */ ;
    defparam LUT__1387.LUTMASK = 16'h233f;
    EFX_LUT4 LUT__1388 (.I0(\u_camera/u_i2c_timing/current_state [2]), .I1(n594), 
            .I2(\u_camera/u_i2c_timing/current_state [0]), .I3(n592), .O(SDA_OE)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0eee */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(504)
    defparam LUT__1388.LUTMASK = 16'h0eee;
    EFX_LUT4 LUT__1389 (.I0(\u_camera/i2c_config_index [3]), .I1(\u_camera/i2c_config_index [4]), 
            .O(n595)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1389.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1390 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [2]), 
            .O(n596)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1390.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1391 (.I0(\u_camera/i2c_config_index [0]), .I1(n596), 
            .O(n597)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1391.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1392 (.I0(n595), .I1(n597), .O(cam_init_ok)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(153)
    defparam LUT__1392.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1393 (.I0(\u_sys/u_disp/h_cnt [7]), .I1(\u_sys/u_disp/h_cnt [8]), 
            .O(n598)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1393.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1394 (.I0(\u_sys/u_disp/h_cnt [6]), .I1(\u_sys/u_disp/h_cnt [9]), 
            .I2(\u_sys/u_disp/h_cnt [10]), .I3(n598), .O(n599)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1394.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1395 (.I0(\u_sys/u_disp/h_cnt [4]), .I1(\u_sys/u_disp/h_cnt [3]), 
            .I2(\u_sys/u_disp/h_cnt [5]), .I3(n599), .O(lcd_hs)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0ff */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(42)
    defparam LUT__1395.LUTMASK = 16'he0ff;
    EFX_LUT4 LUT__1396 (.I0(\u_sys/u_disp/v_cnt [1]), .I1(\u_sys/u_disp/v_cnt [0]), 
            .I2(\u_sys/u_disp/v_cnt [2]), .O(n600)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1396.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1397 (.I0(\u_sys/u_disp/v_cnt [5]), .I1(\u_sys/u_disp/v_cnt [6]), 
            .I2(\u_sys/u_disp/v_cnt [7]), .I3(\u_sys/u_disp/v_cnt [8]), 
            .O(n601)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1397.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1398 (.I0(\u_sys/u_disp/v_cnt [9]), .I1(n601), .O(n602)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1398.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1399 (.I0(\u_sys/u_disp/v_cnt [3]), .I1(\u_sys/u_disp/v_cnt [4]), 
            .I2(n600), .I3(n602), .O(lcd_vs)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfeff */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(43)
    defparam LUT__1399.LUTMASK = 16'hfeff;
    EFX_LUT4 LUT__1400 (.I0(\u_sys/u_disp/v_cnt [0]), .I1(\u_sys/u_disp/v_cnt [1]), 
            .I2(\u_sys/u_disp/v_cnt [2]), .I3(\u_sys/u_disp/v_cnt [3]), 
            .O(n603)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe00 */ ;
    defparam LUT__1400.LUTMASK = 16'hfe00;
    EFX_LUT4 LUT__1401 (.I0(\u_sys/u_disp/v_cnt [5]), .I1(\u_sys/u_disp/v_cnt [6]), 
            .I2(\u_sys/u_disp/v_cnt [7]), .O(n604)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1401.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1402 (.I0(\u_sys/u_disp/v_cnt [4]), .I1(n603), .I2(n604), 
            .I3(\u_sys/u_disp/v_cnt [8]), .O(n605)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h001f */ ;
    defparam LUT__1402.LUTMASK = 16'h001f;
    EFX_LUT4 LUT__1403 (.I0(\u_sys/u_disp/h_cnt [2]), .I1(\u_sys/u_disp/h_cnt [5]), 
            .I2(\u_sys/u_disp/h_cnt [6]), .I3(\u_sys/u_disp/h_cnt [7]), 
            .O(n606)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1403.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1404 (.I0(\u_sys/u_disp/h_cnt [3]), .I1(\u_sys/u_disp/h_cnt [4]), 
            .I2(n606), .O(n607)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1404.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1405 (.I0(\u_sys/u_disp/h_cnt [10]), .I1(\u_sys/u_disp/h_cnt [8]), 
            .I2(n607), .I3(\u_sys/u_disp/h_cnt [9]), .O(n608)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h75ae */ ;
    defparam LUT__1405.LUTMASK = 16'h75ae;
    EFX_LUT4 LUT__1406 (.I0(n603), .I1(\u_sys/u_disp/v_cnt [4]), .I2(n602), 
            .O(n609)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7070 */ ;
    defparam LUT__1406.LUTMASK = 16'h7070;
    EFX_LUT4 LUT__1407 (.I0(n605), .I1(\u_sys/u_disp/v_cnt [9]), .I2(n609), 
            .I3(n608), .O(lcd_de)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0b00 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(45)
    defparam LUT__1407.LUTMASK = 16'h0b00;
    EFX_LUT4 LUT__1408 (.I0(ext_rst_n), .I1(pll_locked), .O(sys_rst_n)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(66)
    defparam LUT__1408.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1409 (.I0(rst_cnt[7]), .I1(rst_cnt[8]), .I2(rst_cnt[10]), 
            .I3(rst_cnt[19]), .O(n610)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1409.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1410 (.I0(rst_cnt[11]), .I1(rst_cnt[12]), .I2(rst_cnt[13]), 
            .I3(rst_cnt[14]), .O(n611)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1410.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1411 (.I0(rst_cnt[15]), .I1(rst_cnt[16]), .I2(rst_cnt[17]), 
            .I3(rst_cnt[18]), .O(n612)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1411.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1412 (.I0(n610), .I1(n611), .I2(n612), .O(n613)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1412.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1413 (.I0(rst_cnt[1]), .I1(rst_cnt[0]), .I2(rst_cnt[2]), 
            .I3(rst_cnt[9]), .O(n614)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1413.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1414 (.I0(rst_cnt[3]), .I1(rst_cnt[4]), .I2(rst_cnt[5]), 
            .I3(rst_cnt[6]), .O(n615)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1414.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1415 (.I0(n613), .I1(n614), .I2(n615), .O(n7)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7f7f */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(58)
    defparam LUT__1415.LUTMASK = 16'h7f7f;
    EFX_LUT4 LUT__1416 (.I0(cam_clk_div[1]), .I1(cam_clk_div[0]), .O(\equal_17/n3 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbbb */ ;   // E:\DennisX\Efinity\together_v2\board_top.v(81)
    defparam LUT__1416.LUTMASK = 16'hbbbb;
    EFX_LUT4 LUT__1417 (.I0(cam_clk_div[0]), .I1(cam_clk_div[1]), .O(n252)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h6666 */ ;
    defparam LUT__1417.LUTMASK = 16'h6666;
    EFX_LUT4 LUT__1418 (.I0(\u_camera/cam_rst_delay_cnt [3]), .I1(\u_camera/cam_rst_delay_cnt [4]), 
            .I2(\u_camera/cam_rst_delay_cnt [5]), .O(n616)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0101 */ ;
    defparam LUT__1418.LUTMASK = 16'h0101;
    EFX_LUT4 LUT__1419 (.I0(n616), .I1(\u_camera/cam_rst_delay_cnt [7]), 
            .I2(\u_camera/cam_rst_delay_cnt [6]), .O(\u_camera/LessThan_11/n16 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbfbf */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(70)
    defparam LUT__1419.LUTMASK = 16'hbfbf;
    EFX_LUT4 LUT__1420 (.I0(\u_camera/u_i2c_timing/clk_cnt [0]), .I1(\u_camera/u_i2c_timing/clk_cnt [2]), 
            .I2(\u_camera/u_i2c_timing/clk_cnt [1]), .O(n617)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1420.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1421 (.I0(\u_camera/u_i2c_timing/clk_cnt [3]), .I1(n617), 
            .O(n618)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1421.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1422 (.I0(\u_camera/u_i2c_timing/clk_cnt [7]), .I1(\u_camera/u_i2c_timing/clk_cnt [6]), 
            .I2(\u_camera/u_i2c_timing/clk_cnt [5]), .O(n619)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1422.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1423 (.I0(\u_camera/u_i2c_timing/delay_cnt [2]), .I1(\u_camera/u_i2c_timing/delay_cnt [3]), 
            .I2(\u_camera/u_i2c_timing/delay_cnt [4]), .I3(\u_camera/u_i2c_timing/delay_cnt [6]), 
            .O(n620)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1423.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1424 (.I0(\u_camera/u_i2c_timing/delay_cnt [0]), .I1(\u_camera/u_i2c_timing/delay_cnt [5]), 
            .I2(\u_camera/u_i2c_timing/delay_cnt [7]), .I3(\u_camera/u_i2c_timing/delay_cnt [11]), 
            .O(n621)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1424.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1425 (.I0(n620), .I1(n621), .O(n622)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1425.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1426 (.I0(\u_camera/u_i2c_timing/delay_cnt [12]), .I1(\u_camera/u_i2c_timing/delay_cnt [13]), 
            .I2(\u_camera/u_i2c_timing/delay_cnt [14]), .O(n623)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1426.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1427 (.I0(\u_camera/u_i2c_timing/delay_cnt [8]), .I1(\u_camera/u_i2c_timing/delay_cnt [9]), 
            .I2(\u_camera/u_i2c_timing/delay_cnt [10]), .O(n624)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1427.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1428 (.I0(\u_camera/u_i2c_timing/delay_cnt [1]), .I1(\u_camera/u_i2c_timing/delay_cnt [15]), 
            .I2(\u_camera/u_i2c_timing/delay_cnt [16]), .O(n625)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1428.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1429 (.I0(n623), .I1(n624), .I2(n625), .O(n626)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1429.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1430 (.I0(n622), .I1(n626), .O(n627)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1430.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1431 (.I0(n618), .I1(\u_camera/u_i2c_timing/clk_cnt [4]), 
            .I2(n619), .I3(n627), .O(n628)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1f00 */ ;
    defparam LUT__1431.LUTMASK = 16'h1f00;
    EFX_LUT4 LUT__1432 (.I0(\u_camera/u_i2c_timing/clk_cnt [0]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1432.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1433 (.I0(CAM_RST_N), .I1(\u_camera/rst_sync [2]), .O(\u_camera/n160 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\camera_top.v(98)
    defparam LUT__1433.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1434 (.I0(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I1(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [2]), .I3(\u_camera/u_i2c_timing/i2c_stream_cnt [3]), 
            .O(n629)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1434.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1435 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .I2(n629), .O(n630)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4040 */ ;
    defparam LUT__1435.LUTMASK = 16'h4040;
    EFX_LUT4 LUT__1436 (.I0(\u_camera/u_i2c_timing/i2c_transfer_en ), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(\u_camera/u_i2c_timing/current_state [3]), .I3(\u_camera/u_i2c_timing/current_state [4]), 
            .O(n631)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h000b */ ;
    defparam LUT__1436.LUTMASK = 16'h000b;
    EFX_LUT4 LUT__1437 (.I0(\u_camera/u_i2c_timing/current_state [2]), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n630), .I3(n631), .O(n632)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1f00 */ ;
    defparam LUT__1437.LUTMASK = 16'h1f00;
    EFX_LUT4 LUT__1438 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(\u_camera/u_i2c_timing/current_state [2]), .I3(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .O(n633)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1438.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1439 (.I0(n595), .I1(n622), .I2(n626), .I3(n633), 
            .O(n634)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4000 */ ;
    defparam LUT__1439.LUTMASK = 16'h4000;
    EFX_LUT4 LUT__1440 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .O(n635)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1440.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1441 (.I0(n635), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .I2(\u_camera/u_i2c_timing/current_state [1]), .I3(\u_camera/u_i2c_timing/current_state [2]), 
            .O(n636)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hca00 */ ;
    defparam LUT__1441.LUTMASK = 16'hca00;
    EFX_LUT4 LUT__1442 (.I0(\u_camera/u_i2c_timing/current_state [2]), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .O(n637)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1442.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1443 (.I0(n637), .I1(n629), .I2(n635), .O(n638)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1443.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1444 (.I0(n629), .I1(n637), .I2(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .I3(\u_camera/u_i2c_timing/current_state [0]), .O(n639)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h004f */ ;
    defparam LUT__1444.LUTMASK = 16'h004f;
    EFX_LUT4 LUT__1445 (.I0(n638), .I1(n639), .I2(n636), .I3(\u_camera/u_i2c_timing/current_state [4]), 
            .O(n640)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe00 */ ;
    defparam LUT__1445.LUTMASK = 16'hfe00;
    EFX_LUT4 LUT__1446 (.I0(\u_camera/u_i2c_timing/current_state [4]), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .O(n641)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1446.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1447 (.I0(\u_camera/u_i2c_timing/i2c_transfer_en ), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(n641), .O(n642)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hb0b0 */ ;
    defparam LUT__1447.LUTMASK = 16'hb0b0;
    EFX_LUT4 LUT__1448 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(n630), .I3(n642), .O(n643)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f00 */ ;
    defparam LUT__1448.LUTMASK = 16'h4f00;
    EFX_LUT4 LUT__1449 (.I0(n634), .I1(n632), .I2(n640), .I3(n643), 
            .O(\u_camera/u_i2c_timing/next_state [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h000b */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(293)
    defparam LUT__1449.LUTMASK = 16'h000b;
    EFX_LUT4 LUT__1450 (.I0(\u_camera/u_i2c_timing/clk_cnt [1]), .I1(\u_camera/u_i2c_timing/clk_cnt [0]), 
            .I2(\u_camera/u_i2c_timing/clk_cnt [2]), .O(n644)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1450.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1451 (.I0(\u_camera/u_i2c_timing/clk_cnt [5]), .I1(\u_camera/u_i2c_timing/clk_cnt [4]), 
            .O(n645)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1451.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1452 (.I0(\u_camera/u_i2c_timing/clk_cnt [3]), .I1(n644), 
            .I2(n645), .I3(\u_camera/u_i2c_timing/clk_cnt [6]), .O(n646)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h001f */ ;
    defparam LUT__1452.LUTMASK = 16'h001f;
    EFX_LUT4 LUT__1453 (.I0(n644), .I1(\u_camera/u_i2c_timing/clk_cnt [3]), 
            .I2(n645), .I3(\u_camera/u_i2c_timing/clk_cnt [6]), .O(n647)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h007f */ ;
    defparam LUT__1453.LUTMASK = 16'h007f;
    EFX_LUT4 LUT__1454 (.I0(n647), .I1(n646), .I2(\u_camera/u_i2c_timing/clk_cnt [7]), 
            .I3(n627), .O(\u_camera/u_i2c_timing/n138 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hc500 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam LUT__1454.LUTMASK = 16'hc500;
    EFX_LUT4 LUT__1455 (.I0(\u_camera/u_i2c_timing/clk_cnt [7]), .I1(\u_camera/u_i2c_timing/clk_cnt [3]), 
            .I2(n627), .O(n648)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1455.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1456 (.I0(\u_camera/u_i2c_timing/clk_cnt [6]), .I1(\u_camera/u_i2c_timing/clk_cnt [5]), 
            .I2(\u_camera/u_i2c_timing/clk_cnt [4]), .I3(\u_camera/u_i2c_timing/clk_cnt [2]), 
            .O(n649)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1456.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1457 (.I0(\u_camera/u_i2c_timing/clk_cnt [0]), .I1(\u_camera/u_i2c_timing/clk_cnt [1]), 
            .I2(n648), .I3(n649), .O(\u_camera/u_i2c_timing/n139 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1000 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam LUT__1457.LUTMASK = 16'h1000;
    EFX_LUT4 LUT__1458 (.I0(\u_camera/u_i2c_timing/clk_cnt [6]), .I1(n617), 
            .I2(n645), .I3(n648), .O(\u_camera/u_i2c_timing/n140 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(82)
    defparam LUT__1458.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1459 (.I0(\u_camera/i2c_config_index [0]), .I1(n595), 
            .O(\u_camera/u_i2c_timing/n197 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(145)
    defparam LUT__1459.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1460 (.I0(\u_camera/u_i2c_timing/current_state [2]), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .O(n650)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1460.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1461 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(\u_camera/u_i2c_timing/current_state [4]), 
            .I2(\u_camera/u_i2c_timing/i2c_transfer_en ), .O(n651)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h9090 */ ;
    defparam LUT__1461.LUTMASK = 16'h9090;
    EFX_LUT4 LUT__1462 (.I0(\u_camera/u_i2c_timing/i2c_ack ), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n650), .I3(n651), .O(\u_camera/u_i2c_timing/n832 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1000 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(148)
    defparam LUT__1462.LUTMASK = 16'h1000;
    EFX_LUT4 LUT__1463 (.I0(\u_camera/u_i2c_timing/n79 [7]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1463.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1464 (.I0(\u_camera/u_i2c_timing/n79 [6]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1464.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1465 (.I0(\u_camera/u_i2c_timing/n79 [5]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1465.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1466 (.I0(\u_camera/u_i2c_timing/n79 [4]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1466.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1467 (.I0(\u_camera/u_i2c_timing/n79 [3]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1467.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1468 (.I0(\u_camera/u_i2c_timing/n79 [2]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1468.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1469 (.I0(\u_camera/u_i2c_timing/n79 [1]), .I1(n628), 
            .O(\u_camera/u_i2c_timing/n121 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(67)
    defparam LUT__1469.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1470 (.I0(n629), .I1(\u_camera/u_i2c_timing/current_state [4]), 
            .I2(\u_camera/u_i2c_timing/current_state [3]), .I3(n635), .O(n652)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbf00 */ ;
    defparam LUT__1470.LUTMASK = 16'hbf00;
    EFX_LUT4 LUT__1471 (.I0(\u_camera/u_i2c_timing/current_state [2]), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .I2(\u_camera/u_i2c_timing/current_state [4]), .O(n653)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1471.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1472 (.I0(\u_camera/u_i2c_timing/current_state [3]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(\u_camera/u_i2c_timing/current_state [4]), .O(n654)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1472.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1473 (.I0(n654), .I1(n629), .I2(n635), .I3(\u_camera/u_i2c_timing/current_state [1]), 
            .O(n655)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd000 */ ;
    defparam LUT__1473.LUTMASK = 16'hd000;
    EFX_LUT4 LUT__1474 (.I0(n652), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n653), .I3(n655), .O(\u_camera/u_i2c_timing/next_state [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h000e */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(293)
    defparam LUT__1474.LUTMASK = 16'h000e;
    EFX_LUT4 LUT__1475 (.I0(n635), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .I2(\u_camera/u_i2c_timing/current_state [2]), .I3(n629), .O(n656)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0cc */ ;
    defparam LUT__1475.LUTMASK = 16'he0cc;
    EFX_LUT4 LUT__1476 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(\u_camera/u_i2c_timing/current_state [0]), .I3(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .O(n657)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h5333 */ ;
    defparam LUT__1476.LUTMASK = 16'h5333;
    EFX_LUT4 LUT__1477 (.I0(\u_camera/u_i2c_timing/current_state [3]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(n657), .I3(\u_camera/u_i2c_timing/current_state [4]), .O(n658)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f00 */ ;
    defparam LUT__1477.LUTMASK = 16'h4f00;
    EFX_LUT4 LUT__1478 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .I2(\u_camera/u_i2c_timing/current_state [3]), .I3(\u_camera/u_i2c_timing/current_state [2]), 
            .O(n659)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbf00 */ ;
    defparam LUT__1478.LUTMASK = 16'hbf00;
    EFX_LUT4 LUT__1479 (.I0(\u_camera/u_i2c_timing/current_state [0]), .I1(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .I2(\u_camera/u_i2c_timing/current_state [1]), .I3(\u_camera/u_i2c_timing/current_state [2]), 
            .O(n660)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7fc0 */ ;
    defparam LUT__1479.LUTMASK = 16'h7fc0;
    EFX_LUT4 LUT__1480 (.I0(n659), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(\u_camera/u_i2c_timing/current_state [4]), .I3(n660), .O(n661)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0e00 */ ;
    defparam LUT__1480.LUTMASK = 16'h0e00;
    EFX_LUT4 LUT__1481 (.I0(n656), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n658), .I3(n661), .O(\u_camera/u_i2c_timing/next_state [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hff70 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(293)
    defparam LUT__1481.LUTMASK = 16'hff70;
    EFX_LUT4 LUT__1482 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [2]), 
            .I2(n629), .I3(n635), .O(n662)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1482.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1483 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(n635), 
            .I2(n650), .I3(\u_camera/u_i2c_timing/current_state [4]), .O(n663)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1f00 */ ;
    defparam LUT__1483.LUTMASK = 16'h1f00;
    EFX_LUT4 LUT__1484 (.I0(\u_camera/u_i2c_timing/current_state [1]), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .I2(\u_camera/u_i2c_timing/i2c_transfer_en ), .I3(\u_camera/u_i2c_timing/current_state [2]), 
            .O(n664)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd000 */ ;
    defparam LUT__1484.LUTMASK = 16'hd000;
    EFX_LUT4 LUT__1485 (.I0(\u_camera/u_i2c_timing/current_state [4]), .I1(\u_camera/u_i2c_timing/current_state [0]), 
            .O(n665)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1485.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1486 (.I0(n664), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n665), .I3(n641), .O(n666)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8a7f */ ;
    defparam LUT__1486.LUTMASK = 16'h8a7f;
    EFX_LUT4 LUT__1487 (.I0(\u_camera/u_i2c_timing/current_state [3]), .I1(n662), 
            .I2(n663), .I3(n666), .O(\u_camera/u_i2c_timing/next_state [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0ff */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(293)
    defparam LUT__1487.LUTMASK = 16'he0ff;
    EFX_LUT4 LUT__1488 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [3]), .O(n667)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4141 */ ;
    defparam LUT__1488.LUTMASK = 16'h4141;
    EFX_LUT4 LUT__1489 (.I0(\u_camera/u_i2c_timing/next_state [2]), .I1(\u_camera/u_i2c_timing/next_state [3]), 
            .O(n668)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1489.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1490 (.I0(n650), .I1(\u_camera/u_i2c_timing/current_state [1]), 
            .I2(n635), .I3(\u_camera/u_i2c_timing/current_state [4]), .O(\u_camera/u_i2c_timing/next_state [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h5780 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(293)
    defparam LUT__1490.LUTMASK = 16'h5780;
    EFX_LUT4 LUT__1491 (.I0(n667), .I1(n668), .I2(\u_camera/u_i2c_timing/next_state [0]), 
            .I3(\u_camera/u_i2c_timing/next_state [4]), .O(n669)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hc3fa */ ;
    defparam LUT__1491.LUTMASK = 16'hc3fa;
    EFX_LUT4 LUT__1492 (.I0(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I1(n669), 
            .O(\u_camera/u_i2c_timing/n482 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1492.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1493 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .O(n670)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1493.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1494 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n666), 
            .I2(n670), .I3(\u_camera/u_i2c_timing/i2c_transfer_en ), .O(ceg_net86)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f00 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(51)
    defparam LUT__1494.LUTMASK = 16'h4f00;
    EFX_LUT4 LUT__1495 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [1]), 
            .O(n671)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1495.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1496 (.I0(\u_camera/i2c_config_index [3]), .I1(\u_camera/i2c_config_index [2]), 
            .I2(\u_camera/i2c_config_index [4]), .I3(n671), .O(n672)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4000 */ ;
    defparam LUT__1496.LUTMASK = 16'h4000;
    EFX_LUT4 LUT__1497 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(n672), 
            .I2(\u_camera/u_i2c_timing/i2c_wdata [0]), .I3(\u_camera/u_i2c_timing/next_state [0]), 
            .O(n673)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h770f */ ;
    defparam LUT__1497.LUTMASK = 16'h770f;
    EFX_LUT4 LUT__1498 (.I0(\u_camera/u_i2c_timing/next_state [2]), .I1(\u_camera/u_i2c_timing/next_state [3]), 
            .O(n674)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1498.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1499 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n675)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he7fe */ ;
    defparam LUT__1499.LUTMASK = 16'he7fe;
    EFX_LUT4 LUT__1500 (.I0(n675), .I1(\u_camera/i2c_config_index [1]), 
            .I2(n672), .I3(\u_camera/u_i2c_timing/next_state [2]), .O(n676)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hee0f */ ;
    defparam LUT__1500.LUTMASK = 16'hee0f;
    EFX_LUT4 LUT__1501 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(\u_camera/i2c_config_index [4]), .O(n677)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd3d3 */ ;
    defparam LUT__1501.LUTMASK = 16'hd3d3;
    EFX_LUT4 LUT__1502 (.I0(\u_camera/i2c_config_index [0]), .I1(n677), 
            .I2(\u_camera/i2c_config_index [2]), .O(n678)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1502.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1503 (.I0(\u_camera/i2c_config_index [3]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [0]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n679)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hdcab */ ;
    defparam LUT__1503.LUTMASK = 16'hdcab;
    EFX_LUT4 LUT__1504 (.I0(\u_camera/i2c_config_index [1]), .I1(n679), 
            .O(n680)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1504.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1505 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [4]), .O(n681)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0d0d */ ;
    defparam LUT__1505.LUTMASK = 16'h0d0d;
    EFX_LUT4 LUT__1506 (.I0(n680), .I1(\u_camera/u_i2c_timing/next_state [4]), 
            .I2(n678), .I3(n681), .O(n682)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h00fe */ ;
    defparam LUT__1506.LUTMASK = 16'h00fe;
    EFX_LUT4 LUT__1507 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(n676), 
            .I2(\u_camera/u_i2c_timing/next_state [1]), .I3(n682), .O(n683)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h00ef */ ;
    defparam LUT__1507.LUTMASK = 16'h00ef;
    EFX_LUT4 LUT__1508 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .I2(n668), .I3(\u_camera/u_i2c_timing/next_state [1]), .O(n684)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe3f */ ;
    defparam LUT__1508.LUTMASK = 16'hfe3f;
    EFX_LUT4 LUT__1509 (.I0(n684), .I1(\u_camera/u_i2c_timing/i2c_wdata [0]), 
            .I2(\u_camera/u_i2c_timing/next_state [4]), .O(n685)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7070 */ ;
    defparam LUT__1509.LUTMASK = 16'h7070;
    EFX_LUT4 LUT__1510 (.I0(n673), .I1(n674), .I2(n683), .I3(n685), 
            .O(\u_camera/u_i2c_timing/n487 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h004f */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1510.LUTMASK = 16'h004f;
    EFX_LUT4 LUT__1511 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(n668), 
            .I2(\u_camera/u_i2c_timing/next_state [0]), .I3(\u_camera/u_i2c_timing/next_state [1]), 
            .O(n686)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'haf03 */ ;
    defparam LUT__1511.LUTMASK = 16'haf03;
    EFX_LUT4 LUT__1512 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n674), 
            .I2(n686), .I3(\u_camera/u_i2c_timing/i2c_transfer_en ), .O(ceg_net135)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hef00 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(51)
    defparam LUT__1512.LUTMASK = 16'hef00;
    EFX_LUT4 LUT__1513 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n668), 
            .O(n687)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1513.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1514 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(n687), .O(n688)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1514.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1515 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .O(n689)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1515.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1516 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(\u_camera/u_i2c_timing/next_state [3]), .I3(n689), .O(n690)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8100 */ ;
    defparam LUT__1516.LUTMASK = 16'h8100;
    EFX_LUT4 LUT__1517 (.I0(\u_camera/u_i2c_timing/i2c_ack5 ), .I1(SDA_IN), 
            .I2(n688), .I3(n690), .O(\u_camera/u_i2c_timing/n553 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcfa */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1517.LUTMASK = 16'hfcfa;
    EFX_LUT4 LUT__1518 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [3]), .O(n691)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1518.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1519 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/next_state [4]), 
            .I2(n691), .O(n692)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h6060 */ ;
    defparam LUT__1519.LUTMASK = 16'h6060;
    EFX_LUT4 LUT__1520 (.I0(\u_camera/u_i2c_timing/i2c_ack4 ), .I1(SDA_IN), 
            .I2(n688), .I3(n692), .O(\u_camera/u_i2c_timing/n556 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcfa */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1520.LUTMASK = 16'hfcfa;
    EFX_LUT4 LUT__1521 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [4]), .O(n693)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1414 */ ;
    defparam LUT__1521.LUTMASK = 16'h1414;
    EFX_LUT4 LUT__1522 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(n693), .O(n694)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1522.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1523 (.I0(\u_camera/u_i2c_timing/i2c_ack3 ), .I1(SDA_IN), 
            .I2(n688), .I3(n694), .O(\u_camera/u_i2c_timing/n559 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcfa */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1523.LUTMASK = 16'hfcfa;
    EFX_LUT4 LUT__1524 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .O(n695)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1524.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1525 (.I0(SDA_IN), .I1(\u_camera/u_i2c_timing/i2c_ack2 ), 
            .I2(n695), .I3(n693), .O(n696)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h5333 */ ;
    defparam LUT__1525.LUTMASK = 16'h5333;
    EFX_LUT4 LUT__1526 (.I0(n688), .I1(n696), .O(\u_camera/u_i2c_timing/n562 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbbb */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1526.LUTMASK = 16'hbbbb;
    EFX_LUT4 LUT__1527 (.I0(n674), .I1(n687), .I2(\u_camera/u_i2c_timing/next_state [0]), 
            .I3(\u_camera/u_i2c_timing/next_state [1]), .O(n697)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he000 */ ;
    defparam LUT__1527.LUTMASK = 16'he000;
    EFX_LUT4 LUT__1528 (.I0(\u_camera/u_i2c_timing/i2c_ack1 ), .I1(SDA_IN), 
            .I2(n688), .I3(n697), .O(\u_camera/u_i2c_timing/n565 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcfa */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1528.LUTMASK = 16'hfcfa;
    EFX_LUT4 LUT__1529 (.I0(\u_camera/u_i2c_timing/i2c_ack4 ), .I1(\u_camera/u_i2c_timing/i2c_ack3 ), 
            .I2(\u_camera/u_i2c_timing/i2c_ack2 ), .I3(\u_camera/u_i2c_timing/i2c_ack1 ), 
            .O(n698)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1529.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1530 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(\u_camera/u_i2c_timing/i2c_ack5 ), 
            .I2(n698), .O(n699)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hb0b0 */ ;
    defparam LUT__1530.LUTMASK = 16'hb0b0;
    EFX_LUT4 LUT__1531 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .I2(\u_camera/u_i2c_timing/next_state [4]), .I3(n674), .O(n700)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4100 */ ;
    defparam LUT__1531.LUTMASK = 16'h4100;
    EFX_LUT4 LUT__1532 (.I0(n699), .I1(\u_camera/u_i2c_timing/i2c_ack ), 
            .I2(n688), .I3(n700), .O(\u_camera/u_i2c_timing/n567 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf5fc */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(485)
    defparam LUT__1532.LUTMASK = 16'hf5fc;
    EFX_LUT4 LUT__1533 (.I0(\u_camera/u_i2c_timing/delay_cnt [11]), .I1(n624), 
            .O(n701)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1533.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1534 (.I0(n701), .I1(n623), .I2(\u_camera/u_i2c_timing/delay_cnt [15]), 
            .I3(\u_camera/u_i2c_timing/delay_cnt [16]), .O(\u_camera/u_i2c_timing/LessThan_6/n34 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0bff */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(38)
    defparam LUT__1534.LUTMASK = 16'h0bff;
    EFX_LUT4 LUT__1535 (.I0(n662), .I1(\u_camera/u_i2c_timing/current_state [3]), 
            .I2(n663), .O(n702)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1535.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1536 (.I0(SDA_OUT), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .I2(\u_camera/u_i2c_timing/next_state [2]), .I3(\u_camera/u_i2c_timing/next_state [1]), 
            .O(n703)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h57c5 */ ;
    defparam LUT__1536.LUTMASK = 16'h57c5;
    EFX_LUT4 LUT__1537 (.I0(\u_camera/u_i2c_timing/i2c_wdata [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [2]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I3(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), 
            .O(n704)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h503f */ ;
    defparam LUT__1537.LUTMASK = 16'h503f;
    EFX_LUT4 LUT__1538 (.I0(\u_camera/u_i2c_timing/i2c_wdata [1]), .I1(\u_camera/u_i2c_timing/i2c_wdata [3]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I3(n704), .O(n705)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf305 */ ;
    defparam LUT__1538.LUTMASK = 16'hf305;
    EFX_LUT4 LUT__1539 (.I0(\u_camera/u_i2c_timing/i2c_wdata [4]), .I1(\u_camera/u_i2c_timing/i2c_wdata [6]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I3(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), 
            .O(n706)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h503f */ ;
    defparam LUT__1539.LUTMASK = 16'h503f;
    EFX_LUT4 LUT__1540 (.I0(\u_camera/u_i2c_timing/i2c_wdata [5]), .I1(\u_camera/u_i2c_timing/i2c_wdata [7]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I3(n706), .O(n707)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf305 */ ;
    defparam LUT__1540.LUTMASK = 16'hf305;
    EFX_LUT4 LUT__1541 (.I0(n707), .I1(n705), .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [2]), 
            .O(n708)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hcaca */ ;
    defparam LUT__1541.LUTMASK = 16'hcaca;
    EFX_LUT4 LUT__1542 (.I0(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I1(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [2]), .O(n709)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1542.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1543 (.I0(\u_camera/u_i2c_timing/i2c_stream_cnt [3]), .I1(n709), 
            .O(n710)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1543.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1544 (.I0(n708), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [1]), .I3(n710), .O(n711)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8000 */ ;
    defparam LUT__1544.LUTMASK = 16'h8000;
    EFX_LUT4 LUT__1545 (.I0(SDA_OUT), .I1(n708), .I2(\u_camera/u_i2c_timing/next_state [2]), 
            .I3(\u_camera/u_i2c_timing/next_state [0]), .O(n712)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h05fc */ ;
    defparam LUT__1545.LUTMASK = 16'h05fc;
    EFX_LUT4 LUT__1546 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(n711), 
            .I2(n712), .I3(\u_camera/u_i2c_timing/next_state [4]), .O(n713)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1546.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1547 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .I2(n668), .O(n714)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4040 */ ;
    defparam LUT__1547.LUTMASK = 16'h4040;
    EFX_LUT4 LUT__1548 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .I2(\u_camera/u_i2c_timing/next_state [3]), .I3(n708), .O(n715)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe40 */ ;
    defparam LUT__1548.LUTMASK = 16'hfe40;
    EFX_LUT4 LUT__1549 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n714), 
            .I2(n715), .O(n716)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0101 */ ;
    defparam LUT__1549.LUTMASK = 16'h0101;
    EFX_LUT4 LUT__1550 (.I0(n703), .I1(n702), .I2(n713), .I3(n716), 
            .O(\u_camera/u_i2c_timing/n481 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfff4 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1550.LUTMASK = 16'hfff4;
    EFX_LUT4 LUT__1551 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n667), 
            .I2(\u_camera/u_i2c_timing/next_state [0]), .I3(\u_camera/u_i2c_timing/i2c_transfer_en ), 
            .O(ceg_net129)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hef00 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(51)
    defparam LUT__1551.LUTMASK = 16'hef00;
    EFX_LUT4 LUT__1552 (.I0(n595), .I1(\u_camera/u_i2c_timing/n188 [1]), 
            .O(\u_camera/u_i2c_timing/n197 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(145)
    defparam LUT__1552.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1553 (.I0(n595), .I1(\u_camera/u_i2c_timing/n188 [2]), 
            .O(\u_camera/u_i2c_timing/n197 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(145)
    defparam LUT__1553.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1554 (.I0(\u_camera/u_i2c_timing/n188 [3]), .I1(n595), 
            .O(\u_camera/u_i2c_timing/n197 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'heeee */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(145)
    defparam LUT__1554.LUTMASK = 16'heeee;
    EFX_LUT4 LUT__1555 (.I0(\u_camera/u_i2c_timing/n188 [4]), .I1(n595), 
            .O(\u_camera/u_i2c_timing/n197 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'heeee */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(145)
    defparam LUT__1555.LUTMASK = 16'heeee;
    EFX_LUT4 LUT__1556 (.I0(n669), .I1(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), 
            .I2(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), .O(\u_camera/u_i2c_timing/n482 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1414 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1556.LUTMASK = 16'h1414;
    EFX_LUT4 LUT__1557 (.I0(\u_camera/u_i2c_timing/i2c_stream_cnt [0]), .I1(\u_camera/u_i2c_timing/i2c_stream_cnt [1]), 
            .I2(n669), .I3(\u_camera/u_i2c_timing/i2c_stream_cnt [2]), .O(\u_camera/u_i2c_timing/n482 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0708 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1557.LUTMASK = 16'h0708;
    EFX_LUT4 LUT__1558 (.I0(n669), .I1(\u_camera/u_i2c_timing/i2c_stream_cnt [3]), 
            .I2(n709), .O(\u_camera/u_i2c_timing/n482 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1414 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1558.LUTMASK = 16'h1414;
    EFX_LUT4 LUT__1559 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(\u_camera/i2c_config_index [0]), .I3(\u_camera/i2c_config_index [4]), 
            .O(n717)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4ccf */ ;
    defparam LUT__1559.LUTMASK = 16'h4ccf;
    EFX_LUT4 LUT__1560 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [2]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [0]), 
            .O(n718)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfc17 */ ;
    defparam LUT__1560.LUTMASK = 16'hfc17;
    EFX_LUT4 LUT__1561 (.I0(\u_camera/i2c_config_index [4]), .I1(n718), 
            .I2(\u_camera/i2c_config_index [3]), .I3(n717), .O(n719)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'heee0 */ ;
    defparam LUT__1561.LUTMASK = 16'heee0;
    EFX_LUT4 LUT__1562 (.I0(n719), .I1(n714), .I2(\u_camera/u_i2c_timing/i2c_wdata [1]), 
            .I3(n684), .O(n720)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0bbb */ ;
    defparam LUT__1562.LUTMASK = 16'h0bbb;
    EFX_LUT4 LUT__1563 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [0]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [4]), 
            .O(n721)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfb4f */ ;
    defparam LUT__1563.LUTMASK = 16'hfb4f;
    EFX_LUT4 LUT__1564 (.I0(n721), .I1(\u_camera/i2c_config_index [2]), 
            .I2(n719), .I3(\u_camera/u_i2c_timing/next_state [1]), .O(n722)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1564.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1565 (.I0(n671), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n723)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h3a00 */ ;
    defparam LUT__1565.LUTMASK = 16'h3a00;
    EFX_LUT4 LUT__1566 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [1]), 
            .I2(n723), .I3(n681), .O(n724)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbb0f */ ;
    defparam LUT__1566.LUTMASK = 16'hbb0f;
    EFX_LUT4 LUT__1567 (.I0(n722), .I1(n661), .I2(n724), .I3(n666), 
            .O(n725)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1567.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1568 (.I0(n720), .I1(\u_camera/u_i2c_timing/next_state [4]), 
            .I2(n725), .O(\u_camera/u_i2c_timing/n487 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f4f */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1568.LUTMASK = 16'h4f4f;
    EFX_LUT4 LUT__1569 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(\u_camera/i2c_config_index [2]), .I3(\u_camera/i2c_config_index [0]), 
            .O(n726)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h3ffa */ ;
    defparam LUT__1569.LUTMASK = 16'h3ffa;
    EFX_LUT4 LUT__1570 (.I0(\u_camera/i2c_config_index [4]), .I1(n726), 
            .O(n727)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1570.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1571 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(\u_camera/i2c_config_index [4]), .O(n728)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1717 */ ;
    defparam LUT__1571.LUTMASK = 16'h1717;
    EFX_LUT4 LUT__1572 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(n728), .I3(\u_camera/i2c_config_index [0]), .O(n729)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbc5f */ ;
    defparam LUT__1572.LUTMASK = 16'hbc5f;
    EFX_LUT4 LUT__1573 (.I0(n729), .I1(n727), .I2(\u_camera/u_i2c_timing/next_state [1]), 
            .I3(n661), .O(n730)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hc500 */ ;
    defparam LUT__1573.LUTMASK = 16'hc500;
    EFX_LUT4 LUT__1574 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n731)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h03fe */ ;
    defparam LUT__1574.LUTMASK = 16'h03fe;
    EFX_LUT4 LUT__1575 (.I0(\u_camera/i2c_config_index [3]), .I1(\u_camera/i2c_config_index [0]), 
            .O(n732)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1575.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1576 (.I0(\u_camera/i2c_config_index [4]), .I1(n732), 
            .I2(n731), .I3(\u_camera/i2c_config_index [1]), .O(n733)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0c05 */ ;
    defparam LUT__1576.LUTMASK = 16'h0c05;
    EFX_LUT4 LUT__1577 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [2]), 
            .I2(n733), .I3(n681), .O(n734)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbb0f */ ;
    defparam LUT__1577.LUTMASK = 16'hbb0f;
    EFX_LUT4 LUT__1578 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(\u_camera/u_i2c_timing/next_state [2]), .I3(\u_camera/u_i2c_timing/next_state [4]), 
            .O(n735)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbf00 */ ;
    defparam LUT__1578.LUTMASK = 16'hbf00;
    EFX_LUT4 LUT__1579 (.I0(n729), .I1(\u_camera/u_i2c_timing/i2c_wdata [2]), 
            .I2(n714), .I3(n735), .O(n736)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h5c00 */ ;
    defparam LUT__1579.LUTMASK = 16'h5c00;
    EFX_LUT4 LUT__1580 (.I0(n734), .I1(n730), .I2(n736), .I3(n666), 
            .O(\u_camera/u_i2c_timing/n487 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcf5 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1580.LUTMASK = 16'hfcf5;
    EFX_LUT4 LUT__1581 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [0]), .I3(\u_camera/i2c_config_index [3]), 
            .O(n737)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h3207 */ ;
    defparam LUT__1581.LUTMASK = 16'h3207;
    EFX_LUT4 LUT__1582 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [1]), .O(n738)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd3d3 */ ;
    defparam LUT__1582.LUTMASK = 16'hd3d3;
    EFX_LUT4 LUT__1583 (.I0(n732), .I1(n738), .I2(n737), .I3(\u_camera/i2c_config_index [2]), 
            .O(n739)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0777 */ ;
    defparam LUT__1583.LUTMASK = 16'h0777;
    EFX_LUT4 LUT__1584 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n739), 
            .I2(n670), .O(n740)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1584.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1585 (.I0(\u_camera/i2c_config_index [4]), .I1(\u_camera/i2c_config_index [2]), 
            .I2(\u_camera/i2c_config_index [0]), .I3(\u_camera/i2c_config_index [3]), 
            .O(n741)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfa3f */ ;
    defparam LUT__1585.LUTMASK = 16'hfa3f;
    EFX_LUT4 LUT__1586 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(\u_camera/i2c_config_index [3]), .O(n742)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd0d0 */ ;
    defparam LUT__1586.LUTMASK = 16'hd0d0;
    EFX_LUT4 LUT__1587 (.I0(\u_camera/i2c_config_index [4]), .I1(\u_camera/i2c_config_index [0]), 
            .O(n743)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1587.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1588 (.I0(n742), .I1(n743), .I2(n741), .I3(\u_camera/i2c_config_index [1]), 
            .O(n744)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hb0bb */ ;
    defparam LUT__1588.LUTMASK = 16'hb0bb;
    EFX_LUT4 LUT__1589 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [3]), 
            .I2(n744), .I3(n681), .O(n745)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1589.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1590 (.I0(n739), .I1(\u_camera/u_i2c_timing/i2c_wdata [3]), 
            .I2(n714), .I3(n735), .O(n746)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h5c00 */ ;
    defparam LUT__1590.LUTMASK = 16'h5c00;
    EFX_LUT4 LUT__1591 (.I0(n745), .I1(n740), .I2(n746), .I3(n666), 
            .O(\u_camera/u_i2c_timing/n487 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfcf5 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1591.LUTMASK = 16'hfcf5;
    EFX_LUT4 LUT__1592 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [0]), 
            .I2(\u_camera/i2c_config_index [2]), .I3(\u_camera/i2c_config_index [4]), 
            .O(n747)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hd08c */ ;
    defparam LUT__1592.LUTMASK = 16'hd08c;
    EFX_LUT4 LUT__1593 (.I0(\u_camera/i2c_config_index [4]), .I1(n597), 
            .I2(n747), .I3(\u_camera/i2c_config_index [3]), .O(n748)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbb0f */ ;
    defparam LUT__1593.LUTMASK = 16'hbb0f;
    EFX_LUT4 LUT__1594 (.I0(n748), .I1(n714), .I2(\u_camera/u_i2c_timing/i2c_wdata [4]), 
            .I3(n684), .O(n749)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0bbb */ ;
    defparam LUT__1594.LUTMASK = 16'h0bbb;
    EFX_LUT4 LUT__1595 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(n732), .O(n750)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h9090 */ ;
    defparam LUT__1595.LUTMASK = 16'h9090;
    EFX_LUT4 LUT__1596 (.I0(n748), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(\u_camera/i2c_config_index [1]), .I3(n750), .O(n751)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0eee */ ;
    defparam LUT__1596.LUTMASK = 16'h0eee;
    EFX_LUT4 LUT__1597 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [4]), 
            .I2(n751), .I3(\u_camera/u_i2c_timing/next_state [3]), .O(n752)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hee0f */ ;
    defparam LUT__1597.LUTMASK = 16'hee0f;
    EFX_LUT4 LUT__1598 (.I0(n752), .I1(\u_camera/u_i2c_timing/next_state [2]), 
            .O(n753)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;
    defparam LUT__1598.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1599 (.I0(n743), .I1(n671), .I2(\u_camera/i2c_config_index [2]), 
            .I3(\u_camera/i2c_config_index [3]), .O(n754)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'haf0c */ ;
    defparam LUT__1599.LUTMASK = 16'haf0c;
    EFX_LUT4 LUT__1600 (.I0(\u_camera/i2c_config_index [4]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(n754), .I3(\u_camera/i2c_config_index [2]), .O(n755)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf00d */ ;
    defparam LUT__1600.LUTMASK = 16'hf00d;
    EFX_LUT4 LUT__1601 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [2]), 
            .I2(\u_camera/i2c_config_index [4]), .I3(\u_camera/i2c_config_index [3]), 
            .O(n756)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe3f */ ;
    defparam LUT__1601.LUTMASK = 16'hfe3f;
    EFX_LUT4 LUT__1602 (.I0(n756), .I1(\u_camera/i2c_config_index [1]), 
            .I2(n755), .O(n757)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0b0b */ ;
    defparam LUT__1602.LUTMASK = 16'h0b0b;
    EFX_LUT4 LUT__1603 (.I0(\u_camera/i2c_config_index [4]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(\u_camera/i2c_config_index [0]), .I3(\u_camera/i2c_config_index [1]), 
            .O(n758)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfe3f */ ;
    defparam LUT__1603.LUTMASK = 16'hfe3f;
    EFX_LUT4 LUT__1604 (.I0(n758), .I1(\u_camera/i2c_config_index [2]), 
            .I2(n595), .O(n759)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0e0e */ ;
    defparam LUT__1604.LUTMASK = 16'h0e0e;
    EFX_LUT4 LUT__1605 (.I0(\u_camera/u_i2c_timing/next_state [1]), .I1(n759), 
            .O(n760)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;
    defparam LUT__1605.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1606 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(n674), 
            .I2(n668), .I3(n760), .O(n761)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h00f8 */ ;
    defparam LUT__1606.LUTMASK = 16'h00f8;
    EFX_LUT4 LUT__1607 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n757), 
            .I2(n681), .I3(n761), .O(n762)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h00f1 */ ;
    defparam LUT__1607.LUTMASK = 16'h00f1;
    EFX_LUT4 LUT__1608 (.I0(n753), .I1(n762), .I2(n749), .I3(\u_camera/u_i2c_timing/next_state [4]), 
            .O(\u_camera/u_i2c_timing/n487 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f44 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1608.LUTMASK = 16'h4f44;
    EFX_LUT4 LUT__1609 (.I0(n759), .I1(\u_camera/u_i2c_timing/next_state [1]), 
            .I2(\u_camera/u_i2c_timing/i2c_wdata [5]), .I3(\u_camera/u_i2c_timing/next_state [0]), 
            .O(n763)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1609.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1610 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n764)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1610.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1611 (.I0(\u_camera/i2c_config_index [3]), .I1(\u_camera/i2c_config_index [1]), 
            .I2(\u_camera/i2c_config_index [2]), .I3(\u_camera/i2c_config_index [0]), 
            .O(n765)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1f75 */ ;
    defparam LUT__1611.LUTMASK = 16'h1f75;
    EFX_LUT4 LUT__1612 (.I0(n765), .I1(n764), .I2(\u_camera/u_i2c_timing/next_state [4]), 
            .I3(\u_camera/i2c_config_index [4]), .O(n766)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h030a */ ;
    defparam LUT__1612.LUTMASK = 16'h030a;
    EFX_LUT4 LUT__1613 (.I0(n766), .I1(n681), .I2(n674), .I3(n763), 
            .O(n767)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0eee */ ;
    defparam LUT__1613.LUTMASK = 16'h0eee;
    EFX_LUT4 LUT__1614 (.I0(\u_camera/u_i2c_timing/i2c_wdata [5]), .I1(n668), 
            .I2(\u_camera/u_i2c_timing/next_state [4]), .O(n768)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1614.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1615 (.I0(\u_camera/u_i2c_timing/next_state [3]), .I1(\u_camera/u_i2c_timing/next_state [0]), 
            .I2(\u_camera/u_i2c_timing/next_state [1]), .I3(n768), .O(n769)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hef00 */ ;
    defparam LUT__1615.LUTMASK = 16'hef00;
    EFX_LUT4 LUT__1616 (.I0(n671), .I1(n743), .O(n770)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;
    defparam LUT__1616.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1617 (.I0(n770), .I1(\u_camera/i2c_config_index [2]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(\u_camera/i2c_config_index [4]), 
            .O(n771)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hfdd3 */ ;
    defparam LUT__1617.LUTMASK = 16'hfdd3;
    EFX_LUT4 LUT__1618 (.I0(n771), .I1(\u_camera/u_i2c_timing/i2c_wdata [5]), 
            .I2(n695), .I3(n668), .O(n772)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'ha300 */ ;
    defparam LUT__1618.LUTMASK = 16'ha300;
    EFX_LUT4 LUT__1619 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(\u_camera/u_i2c_timing/next_state [3]), 
            .I2(n771), .I3(n670), .O(n773)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0100 */ ;
    defparam LUT__1619.LUTMASK = 16'h0100;
    EFX_LUT4 LUT__1620 (.I0(n695), .I1(n760), .I2(n687), .I3(n773), 
            .O(n774)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h001f */ ;
    defparam LUT__1620.LUTMASK = 16'h001f;
    EFX_LUT4 LUT__1621 (.I0(n769), .I1(n772), .I2(n767), .I3(n774), 
            .O(\u_camera/u_i2c_timing/n487 [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h01ff */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1621.LUTMASK = 16'h01ff;
    EFX_LUT4 LUT__1622 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(\u_camera/i2c_config_index [1]), .I3(\u_camera/i2c_config_index [2]), 
            .O(n775)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0110 */ ;
    defparam LUT__1622.LUTMASK = 16'h0110;
    EFX_LUT4 LUT__1623 (.I0(n775), .I1(\u_camera/i2c_config_index [4]), 
            .I2(n714), .I3(\u_camera/u_i2c_timing/next_state [4]), .O(n776)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7f00 */ ;
    defparam LUT__1623.LUTMASK = 16'h7f00;
    EFX_LUT4 LUT__1624 (.I0(\u_camera/i2c_config_index [4]), .I1(n670), 
            .I2(n775), .O(n777)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8080 */ ;
    defparam LUT__1624.LUTMASK = 16'h8080;
    EFX_LUT4 LUT__1625 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [0]), 
            .I2(\u_camera/i2c_config_index [2]), .I3(\u_camera/i2c_config_index [4]), 
            .O(n778)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h3ff2 */ ;
    defparam LUT__1625.LUTMASK = 16'h3ff2;
    EFX_LUT4 LUT__1626 (.I0(\u_camera/i2c_config_index [4]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(n778), .O(n779)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbcbc */ ;
    defparam LUT__1626.LUTMASK = 16'hbcbc;
    EFX_LUT4 LUT__1627 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [6]), 
            .I2(n779), .I3(n681), .O(n780)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1627.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1628 (.I0(\u_camera/u_i2c_timing/next_state [4]), .I1(n777), 
            .I2(n780), .I3(n666), .O(n781)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hee0f */ ;
    defparam LUT__1628.LUTMASK = 16'hee0f;
    EFX_LUT4 LUT__1629 (.I0(n684), .I1(\u_camera/u_i2c_timing/i2c_wdata [6]), 
            .I2(n776), .I3(n781), .O(\u_camera/u_i2c_timing/n487 [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8f00 */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1629.LUTMASK = 16'h8f00;
    EFX_LUT4 LUT__1630 (.I0(\u_camera/i2c_config_index [0]), .I1(\u_camera/i2c_config_index [4]), 
            .I2(\u_camera/i2c_config_index [3]), .I3(n596), .O(n782)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1c00 */ ;
    defparam LUT__1630.LUTMASK = 16'h1c00;
    EFX_LUT4 LUT__1631 (.I0(n714), .I1(n782), .I2(\u_camera/u_i2c_timing/i2c_wdata [7]), 
            .I3(n684), .O(n783)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0777 */ ;
    defparam LUT__1631.LUTMASK = 16'h0777;
    EFX_LUT4 LUT__1632 (.I0(\u_camera/i2c_config_index [2]), .I1(\u_camera/i2c_config_index [3]), 
            .I2(n671), .O(n784)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1010 */ ;
    defparam LUT__1632.LUTMASK = 16'h1010;
    EFX_LUT4 LUT__1633 (.I0(\u_camera/i2c_config_index [4]), .I1(n784), 
            .I2(n782), .I3(\u_camera/u_i2c_timing/next_state [1]), .O(n785)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h770f */ ;
    defparam LUT__1633.LUTMASK = 16'h770f;
    EFX_LUT4 LUT__1634 (.I0(\u_camera/i2c_config_index [1]), .I1(\u_camera/i2c_config_index [0]), 
            .I2(\u_camera/i2c_config_index [2]), .I3(\u_camera/i2c_config_index [3]), 
            .O(n786)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h9ef3 */ ;
    defparam LUT__1634.LUTMASK = 16'h9ef3;
    EFX_LUT4 LUT__1635 (.I0(n732), .I1(\u_camera/i2c_config_index [4]), 
            .I2(n786), .O(n787)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h7c7c */ ;
    defparam LUT__1635.LUTMASK = 16'h7c7c;
    EFX_LUT4 LUT__1636 (.I0(\u_camera/u_i2c_timing/next_state [0]), .I1(\u_camera/u_i2c_timing/i2c_wdata [7]), 
            .I2(n787), .I3(n681), .O(n788)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1636.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1637 (.I0(n785), .I1(n661), .I2(n788), .I3(n666), 
            .O(n789)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hbbf0 */ ;
    defparam LUT__1637.LUTMASK = 16'hbbf0;
    EFX_LUT4 LUT__1638 (.I0(n783), .I1(\u_camera/u_i2c_timing/next_state [4]), 
            .I2(n789), .O(\u_camera/u_i2c_timing/n487 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4f4f */ ;   // E:\DennisX\Efinity\together_v2\i2c_timing_ctrl_reg16_dat16.v(439)
    defparam LUT__1638.LUTMASK = 16'h4f4f;
    EFX_LUT4 LUT__1708 (.I0(\u_sys/u_disp/v_cnt [3]), .I1(n600), .I2(\u_sys/u_disp/v_cnt [4]), 
            .I3(n604), .O(n807)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'hf800 */ ;
    defparam LUT__1708.LUTMASK = 16'hf800;
    EFX_LUT4 LUT__1709 (.I0(n807), .I1(\u_sys/u_disp/v_cnt [8]), .I2(\u_sys/u_disp/v_cnt [9]), 
            .O(n808)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'he0e0 */ ;
    defparam LUT__1709.LUTMASK = 16'he0e0;
    EFX_LUT4 LUT__1710 (.I0(\u_sys/u_disp/v_cnt [0]), .I1(n808), .O(\u_sys/u_disp/u_vga_timing/n37 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h1111 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1710.LUTMASK = 16'h1111;
    EFX_LUT4 LUT__1711 (.I0(\u_sys/u_disp/h_cnt [0]), .I1(\u_sys/u_disp/h_cnt [1]), 
            .I2(\u_sys/u_disp/h_cnt [2]), .I3(\u_sys/u_disp/h_cnt [3]), 
            .O(n809)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h0001 */ ;
    defparam LUT__1711.LUTMASK = 16'h0001;
    EFX_LUT4 LUT__1712 (.I0(n809), .I1(\u_sys/u_disp/h_cnt [5]), .I2(\u_sys/u_disp/h_cnt [6]), 
            .I3(\u_sys/u_disp/h_cnt [4]), .O(n810)) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4000 */ ;
    defparam LUT__1712.LUTMASK = 16'h4000;
    EFX_LUT4 LUT__1713 (.I0(n810), .I1(n598), .I2(\u_sys/u_disp/h_cnt [9]), 
            .I3(\u_sys/u_disp/h_cnt [10]), .O(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 )) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4fff */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(29)
    defparam LUT__1713.LUTMASK = 16'h4fff;
    EFX_LUT4 LUT__1714 (.I0(\u_sys/u_disp/h_cnt [0]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [0])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1714.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1715 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [1]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1715.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1716 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [2]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1716.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1717 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [3]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1717.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1718 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [4]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1718.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1719 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [5]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1719.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1720 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [6]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1720.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1721 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [7]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1721.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1722 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [8]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1722.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1723 (.I0(n808), .I1(\u_sys/u_disp/u_vga_timing/n24 [9]), 
            .O(\u_sys/u_disp/u_vga_timing/n37 [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h4444 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(36)
    defparam LUT__1723.LUTMASK = 16'h4444;
    EFX_LUT4 LUT__1724 (.I0(\u_sys/u_disp/u_vga_timing/n9 [1]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [1])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1724.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1725 (.I0(\u_sys/u_disp/u_vga_timing/n9 [2]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [2])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1725.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1726 (.I0(\u_sys/u_disp/u_vga_timing/n9 [3]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [3])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1726.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1727 (.I0(\u_sys/u_disp/u_vga_timing/n9 [4]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [4])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1727.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1728 (.I0(\u_sys/u_disp/u_vga_timing/n9 [5]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [5])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1728.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1729 (.I0(\u_sys/u_disp/u_vga_timing/n9 [6]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [6])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1729.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1730 (.I0(\u_sys/u_disp/u_vga_timing/n9 [7]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [7])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1730.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1731 (.I0(\u_sys/u_disp/u_vga_timing/n9 [8]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [8])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1731.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1732 (.I0(\u_sys/u_disp/u_vga_timing/n9 [9]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [9])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1732.LUTMASK = 16'h8888;
    EFX_LUT4 LUT__1733 (.I0(\u_sys/u_disp/u_vga_timing/n9 [10]), .I1(\u_sys/u_disp/u_vga_timing/LessThan_6/n22 ), 
            .O(\u_sys/u_disp/u_vga_timing/n50 [10])) /* verific EFX_ATTRIBUTE_CELL_NAME=EFX_LUT4, LUTMASK=16'h8888 */ ;   // E:\DennisX\Efinity\together_v2\vga_1280_720_timingv.v(37)
    defparam LUT__1733.LUTMASK = 16'h8888;
    
endmodule

//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_0
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_1
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_0
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_1
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_2
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_3
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_4
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_5
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_FF_4afb7fe5_6
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_ADD_4afb7fe5_0
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_2
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_3
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_4
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_5
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_6
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_7
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_8
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_9
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_10
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_11
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_12
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_13
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_14
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_15
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_16
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_17
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_18
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_19
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_20
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_21
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_22
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_23
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_24
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_25
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_26
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_27
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_28
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_29
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_30
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_31
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_32
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_33
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_34
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_35
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_36
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_37
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_38
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_39
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_40
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_41
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_42
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_43
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_44
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_45
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_46
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_47
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_48
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_49
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_50
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_51
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_52
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_53
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_54
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_55
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_56
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_57
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_58
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_59
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_60
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_61
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_62
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_63
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_64
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_65
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_66
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_67
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_68
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_69
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_70
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_71
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_72
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_73
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_74
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_75
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_76
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_77
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_78
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_79
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_80
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_81
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_82
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_83
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_84
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_85
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_86
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_87
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_88
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_89
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_90
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_91
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_92
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_93
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_94
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_95
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_96
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_97
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_98
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_99
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_100
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_101
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_102
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_103
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_104
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_105
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_106
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_107
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_108
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_109
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_110
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_111
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_112
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_113
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_114
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_115
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_116
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_117
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_118
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_119
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_120
// module not written out since it is a black box. 
//


//
// Verific Verilog Description of module EFX_LUT4_4afb7fe5_121
// module not written out since it is a black box. 
//

